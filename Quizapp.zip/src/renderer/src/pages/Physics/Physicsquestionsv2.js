


import Ch6q1 from "./Phyquestions/Chapter-6/1.png"
import Ch6q1a1 from "./Phyquestions/Chapter-6/1 (1).png"
import Ch6q1a2 from "./Phyquestions/Chapter-6/1 (2).png"
import Ch6q1a3 from "./Phyquestions/Chapter-6/1 (3).png"
import Ch6q1a4 from "./Phyquestions/Chapter-6/1 (4).png"



import Ch6q2 from "./Phyquestions/Chapter-6/2.png"
import Ch6q2a1 from "./Phyquestions/Chapter-6/2 (1).png"
import Ch6q2a2 from "./Phyquestions/Chapter-6/2 (2).png"
import Ch6q2a3 from "./Phyquestions/Chapter-6/2 (3).png"
import Ch6q2a4 from "./Phyquestions/Chapter-6/2 (4).png"

import Ch6q3 from "./Phyquestions/Chapter-6/3.png"
import Ch6q3a1 from "./Phyquestions/Chapter-6/3 (1).png"
import Ch6q3a2 from "./Phyquestions/Chapter-6/3 (2).png"
import Ch6q3a3 from "./Phyquestions/Chapter-6/3 (3).png"
import Ch6q3a4 from "./Phyquestions/Chapter-6/3 (4).png"

import Ch6q4 from "./Phyquestions/Chapter-6/4.png"
import Ch6q4a1 from "./Phyquestions/Chapter-6/4 (1).png"
import Ch6q4a2 from "./Phyquestions/Chapter-6/4 (2).png"
import Ch6q4a3 from "./Phyquestions/Chapter-6/4 (3).png"
import Ch6q4a4 from "./Phyquestions/Chapter-6/4 (4).png"

import Ch6q5 from "./Phyquestions/Chapter-6/5.png"
import Ch6q5a1 from "./Phyquestions/Chapter-6/5 (1).png"
import Ch6q5a2 from "./Phyquestions/Chapter-6/5 (2).png"
import Ch6q5a3 from "./Phyquestions/Chapter-6/5 (3).png"
import Ch6q5a4 from "./Phyquestions/Chapter-6/5 (4).png"

import Ch6q6 from "./Phyquestions/Chapter-6/6.png"
import Ch6q6a1 from "./Phyquestions/Chapter-6/6 (1).png"
import Ch6q6a2 from "./Phyquestions/Chapter-6/6 (2).png"
import Ch6q6a3 from "./Phyquestions/Chapter-6/6 (3).png"
import Ch6q6a4 from "./Phyquestions/Chapter-6/6 (4).png"

import Ch6q7 from "./Phyquestions/Chapter-6/7.png"
import Ch6q7a1 from "./Phyquestions/Chapter-6/7 (1).png"
import Ch6q7a2 from "./Phyquestions/Chapter-6/7 (2).png"
import Ch6q7a3 from "./Phyquestions/Chapter-6/7 (3).png"
import Ch6q7a4 from "./Phyquestions/Chapter-6/7 (4).png"

import Ch6q8 from "./Phyquestions/Chapter-6/8.png"
import Ch6q8a1 from "./Phyquestions/Chapter-6/8 (1).png"
import Ch6q8a2 from "./Phyquestions/Chapter-6/8 (2).png"
import Ch6q8a3 from "./Phyquestions/Chapter-6/8 (3).png"
import Ch6q8a4 from "./Phyquestions/Chapter-6/8 (4).png"

import Ch6q9 from "./Phyquestions/Chapter-6/9.png"
import Ch6q9a1 from "./Phyquestions/Chapter-6/9 (1).png"
import Ch6q9a2 from "./Phyquestions/Chapter-6/9 (2).png"
import Ch6q9a3 from "./Phyquestions/Chapter-6/9 (3).png"
import Ch6q9a4 from "./Phyquestions/Chapter-6/9 (4).png"

import Ch6q10 from "./Phyquestions/Chapter-6/10.png"
import Ch6q10a1 from "./Phyquestions/Chapter-6/10 (1).png"
import Ch6q10a2 from "./Phyquestions/Chapter-6/10 (2).png"
import Ch6q10a3 from "./Phyquestions/Chapter-6/10 (3).png"
import Ch6q10a4 from "./Phyquestions/Chapter-6/10 (4).png"



import Ch7q1 from "./Phyquestions/Chapter-7/1.png"
import Ch7q1a1 from "./Phyquestions/Chapter-7/1 (1).png"
import Ch7q1a2 from "./Phyquestions/Chapter-7/1 (2).png"
import Ch7q1a3 from "./Phyquestions/Chapter-7/1 (3).png"
import Ch7q1a4 from "./Phyquestions/Chapter-7/1 (4).png"



import Ch7q2 from "./Phyquestions/Chapter-7/2.png"
import Ch7q2a1 from "./Phyquestions/Chapter-7/2 (1).png"
import Ch7q2a2 from "./Phyquestions/Chapter-7/2 (2).png"
import Ch7q2a3 from "./Phyquestions/Chapter-7/2 (3).png"
import Ch7q2a4 from "./Phyquestions/Chapter-7/2 (4).png"

import Ch7q3 from "./Phyquestions/Chapter-7/3.png"
import Ch7q3a1 from "./Phyquestions/Chapter-7/3 (1).png"
import Ch7q3a2 from "./Phyquestions/Chapter-7/3 (2).png"
import Ch7q3a3 from "./Phyquestions/Chapter-7/3 (3).png"
import Ch7q3a4 from "./Phyquestions/Chapter-7/3 (4).png"

import Ch7q4 from "./Phyquestions/Chapter-7/4.png"
import Ch7q4a1 from "./Phyquestions/Chapter-7/4 (1).png"
import Ch7q4a2 from "./Phyquestions/Chapter-7/4 (2).png"
import Ch7q4a3 from "./Phyquestions/Chapter-7/4 (3).png"
import Ch7q4a4 from "./Phyquestions/Chapter-7/4 (4).png"

import Ch7q5 from "./Phyquestions/Chapter-7/5.png"
import Ch7q5a1 from "./Phyquestions/Chapter-7/5 (1).png"
import Ch7q5a2 from "./Phyquestions/Chapter-7/5 (2).png"
import Ch7q5a3 from "./Phyquestions/Chapter-7/5 (3).png"
import Ch7q5a4 from "./Phyquestions/Chapter-7/5 (4).png"

import Ch7q6 from "./Phyquestions/Chapter-7/6.png"
import Ch7q6a1 from "./Phyquestions/Chapter-7/6 (1).png"
import Ch7q6a2 from "./Phyquestions/Chapter-7/6 (2).png"
import Ch7q6a3 from "./Phyquestions/Chapter-7/6 (3).png"
import Ch7q6a4 from "./Phyquestions/Chapter-7/6 (4).png"

import Ch7q7 from "./Phyquestions/Chapter-7/7.png"
import Ch7q7a1 from "./Phyquestions/Chapter-7/7 (1).png"
import Ch7q7a2 from "./Phyquestions/Chapter-7/7 (2).png"
import Ch7q7a3 from "./Phyquestions/Chapter-7/7 (3).png"
import Ch7q7a4 from "./Phyquestions/Chapter-7/7 (4).png"

import Ch7q8 from "./Phyquestions/Chapter-7/8.png"
import Ch7q8a1 from "./Phyquestions/Chapter-7/8 (1).png"
import Ch7q8a2 from "./Phyquestions/Chapter-7/8 (2).png"
import Ch7q8a3 from "./Phyquestions/Chapter-7/8 (3).png"
import Ch7q8a4 from "./Phyquestions/Chapter-7/8 (4).png"

import Ch7q9 from "./Phyquestions/Chapter-7/9.png"
import Ch7q9a1 from "./Phyquestions/Chapter-7/9 (1).png"
import Ch7q9a2 from "./Phyquestions/Chapter-7/9 (2).png"
import Ch7q9a3 from "./Phyquestions/Chapter-7/9 (3).png"
import Ch7q9a4 from "./Phyquestions/Chapter-7/9 (4).png"

import Ch7q10 from "./Phyquestions/Chapter-7/10.png"
import Ch7q10a1 from "./Phyquestions/Chapter-7/10 (1).png"
import Ch7q10a2 from "./Phyquestions/Chapter-7/10 (2).png"
import Ch7q10a3 from "./Phyquestions/Chapter-7/10 (3).png"
import Ch7q10a4 from "./Phyquestions/Chapter-7/10 (4).png"



import Ch8q1 from "./Phyquestions/Chapter-8/1.png"
import Ch8q1a1 from "./Phyquestions/Chapter-8/1 (1).png"
import Ch8q1a2 from "./Phyquestions/Chapter-8/1 (2).png"
import Ch8q1a3 from "./Phyquestions/Chapter-8/1 (3).png"
import Ch8q1a4 from "./Phyquestions/Chapter-8/1 (4).png"



import Ch8q2 from "./Phyquestions/Chapter-8/2.png"
import Ch8q2a1 from "./Phyquestions/Chapter-8/2 (1).png"
import Ch8q2a2 from "./Phyquestions/Chapter-8/2 (2).png"
import Ch8q2a3 from "./Phyquestions/Chapter-8/2 (3).png"
import Ch8q2a4 from "./Phyquestions/Chapter-8/2 (4).png"

import Ch8q3 from "./Phyquestions/Chapter-8/3.png"
import Ch8q3a1 from "./Phyquestions/Chapter-8/3 (1).png"
import Ch8q3a2 from "./Phyquestions/Chapter-8/3 (2).png"
import Ch8q3a3 from "./Phyquestions/Chapter-8/3 (3).png"
import Ch8q3a4 from "./Phyquestions/Chapter-8/3 (4).png"

import Ch8q4 from "./Phyquestions/Chapter-8/4.png"
import Ch8q4a1 from "./Phyquestions/Chapter-8/4 (1).png"
import Ch8q4a2 from "./Phyquestions/Chapter-8/4 (2).png"
import Ch8q4a3 from "./Phyquestions/Chapter-8/4 (3).png"
import Ch8q4a4 from "./Phyquestions/Chapter-8/4 (4).png"

import Ch8q5 from "./Phyquestions/Chapter-8/5.png"
import Ch8q5a1 from "./Phyquestions/Chapter-8/5 (1).png"
import Ch8q5a2 from "./Phyquestions/Chapter-8/5 (2).png"
import Ch8q5a3 from "./Phyquestions/Chapter-8/5 (3).png"
import Ch8q5a4 from "./Phyquestions/Chapter-8/5 (4).png"

import Ch8q6 from "./Phyquestions/Chapter-8/6.png"
import Ch8q6a1 from "./Phyquestions/Chapter-8/6 (1).png"
import Ch8q6a2 from "./Phyquestions/Chapter-8/6 (2).png"
import Ch8q6a3 from "./Phyquestions/Chapter-8/6 (3).png"
import Ch8q6a4 from "./Phyquestions/Chapter-8/6 (4).png"

import Ch8q7 from "./Phyquestions/Chapter-8/7.png"
import Ch8q7a1 from "./Phyquestions/Chapter-8/7 (1).png"
import Ch8q7a2 from "./Phyquestions/Chapter-8/7 (2).png"
import Ch8q7a3 from "./Phyquestions/Chapter-8/7 (3).png"
import Ch8q7a4 from "./Phyquestions/Chapter-8/7 (4).png"

import Ch8q8 from "./Phyquestions/Chapter-8/8.png"
import Ch8q8a1 from "./Phyquestions/Chapter-8/8 (1).png"
import Ch8q8a2 from "./Phyquestions/Chapter-8/8 (2).png"
import Ch8q8a3 from "./Phyquestions/Chapter-8/8 (3).png"
import Ch8q8a4 from "./Phyquestions/Chapter-8/8 (4).png"

import Ch8q9 from "./Phyquestions/Chapter-8/9.png"
import Ch8q9a1 from "./Phyquestions/Chapter-8/9 (1).png"
import Ch8q9a2 from "./Phyquestions/Chapter-8/9 (2).png"
import Ch8q9a3 from "./Phyquestions/Chapter-8/9 (3).png"
import Ch8q9a4 from "./Phyquestions/Chapter-8/9 (4).png"

import Ch8q10 from "./Phyquestions/Chapter-8/10.png"
import Ch8q10a1 from "./Phyquestions/Chapter-8/10 (1).png"
import Ch8q10a2 from "./Phyquestions/Chapter-8/10 (2).png"
import Ch8q10a3 from "./Phyquestions/Chapter-8/10 (3).png"
import Ch8q10a4 from "./Phyquestions/Chapter-8/10 (4).png"

import Ch8q11 from "./Phyquestions/Chapter-8/11.png"
import Ch8q11a1 from "./Phyquestions/Chapter-8/11 (1).png"
import Ch8q11a2 from "./Phyquestions/Chapter-8/11 (2).png"
import Ch8q11a3 from "./Phyquestions/Chapter-8/11 (3).png"
import Ch8q11a4 from "./Phyquestions/Chapter-8/11 (4).png"

import Ch8q12 from "./Phyquestions/Chapter-8/12.png"
import Ch8q12a1 from "./Phyquestions/Chapter-8/12 (1).png"
import Ch8q12a2 from "./Phyquestions/Chapter-8/12 (2).png"
import Ch8q12a3 from "./Phyquestions/Chapter-8/12 (3).png"
import Ch8q12a4 from "./Phyquestions/Chapter-8/12 (4).png"

import Ch8q13 from "./Phyquestions/Chapter-8/13.png"
import Ch8q13a1 from "./Phyquestions/Chapter-8/13 (1).png"
import Ch8q13a2 from "./Phyquestions/Chapter-8/13 (2).png"
import Ch8q13a3 from "./Phyquestions/Chapter-8/13 (3).png"
import Ch8q13a4 from "./Phyquestions/Chapter-8/13 (4).png"

import Ch8q14 from "./Phyquestions/Chapter-8/14.png"
import Ch8q14a1 from "./Phyquestions/Chapter-8/14 (1).png"
import Ch8q14a2 from "./Phyquestions/Chapter-8/14 (2).png"
import Ch8q14a3 from "./Phyquestions/Chapter-8/14 (3).png"
import Ch8q14a4 from "./Phyquestions/Chapter-8/14 (4).png"

import Ch8q15 from "./Phyquestions/Chapter-8/15.png"
import Ch8q15a1 from "./Phyquestions/Chapter-8/15 (1).png"
import Ch8q15a2 from "./Phyquestions/Chapter-8/15 (2).png"
import Ch8q15a3 from "./Phyquestions/Chapter-8/15 (3).png"
import Ch8q15a4 from "./Phyquestions/Chapter-8/15 (4).png"



import Ch9q1 from "./Phyquestions/Chapter-9/1.png"
import Ch9q1a1 from "./Phyquestions/Chapter-9/1 (1).png"
import Ch9q1a2 from "./Phyquestions/Chapter-9/1 (2).png"
import Ch9q1a3 from "./Phyquestions/Chapter-9/1 (3).png"
import Ch9q1a4 from "./Phyquestions/Chapter-9/1 (4).png"



import Ch9q2 from "./Phyquestions/Chapter-9/2.png"
import Ch9q2a1 from "./Phyquestions/Chapter-9/2 (1).png"
import Ch9q2a2 from "./Phyquestions/Chapter-9/2 (2).png"
import Ch9q2a3 from "./Phyquestions/Chapter-9/2 (3).png"
import Ch9q2a4 from "./Phyquestions/Chapter-9/2 (4).png"

import Ch9q3 from "./Phyquestions/Chapter-9/3.png"
import Ch9q3a1 from "./Phyquestions/Chapter-9/3 (1).png"
import Ch9q3a2 from "./Phyquestions/Chapter-9/3 (2).png"
import Ch9q3a3 from "./Phyquestions/Chapter-9/3 (3).png"
import Ch9q3a4 from "./Phyquestions/Chapter-9/3 (4).png"

import Ch9q4 from "./Phyquestions/Chapter-9/4.png"
import Ch9q4a1 from "./Phyquestions/Chapter-9/4 (1).png"
import Ch9q4a2 from "./Phyquestions/Chapter-9/4 (2).png"
import Ch9q4a3 from "./Phyquestions/Chapter-9/4 (3).png"
import Ch9q4a4 from "./Phyquestions/Chapter-9/4 (4).png"

import Ch9q5 from "./Phyquestions/Chapter-9/5.png"
import Ch9q5a1 from "./Phyquestions/Chapter-9/5 (1).png"
import Ch9q5a2 from "./Phyquestions/Chapter-9/5 (2).png"
import Ch9q5a3 from "./Phyquestions/Chapter-9/5 (3).png"
import Ch9q5a4 from "./Phyquestions/Chapter-9/5 (4).png"

import Ch9q6 from "./Phyquestions/Chapter-9/6.png"
import Ch9q6a1 from "./Phyquestions/Chapter-9/6 (1).png"
import Ch9q6a2 from "./Phyquestions/Chapter-9/6 (2).png"
import Ch9q6a3 from "./Phyquestions/Chapter-9/6 (3).png"
import Ch9q6a4 from "./Phyquestions/Chapter-9/6 (4).png"

import Ch9q7 from "./Phyquestions/Chapter-9/7.png"
import Ch9q7a1 from "./Phyquestions/Chapter-9/7 (1).png"
import Ch9q7a2 from "./Phyquestions/Chapter-9/7 (2).png"
import Ch9q7a3 from "./Phyquestions/Chapter-9/7 (3).png"
import Ch9q7a4 from "./Phyquestions/Chapter-9/7 (4).png"

import Ch9q8 from "./Phyquestions/Chapter-9/8.png"
import Ch9q8a1 from "./Phyquestions/Chapter-9/8 (1).png"
import Ch9q8a2 from "./Phyquestions/Chapter-9/8 (2).png"
import Ch9q8a3 from "./Phyquestions/Chapter-9/8 (3).png"
import Ch9q8a4 from "./Phyquestions/Chapter-9/8 (4).png"

import Ch9q9 from "./Phyquestions/Chapter-9/9.png"
import Ch9q9a1 from "./Phyquestions/Chapter-9/9 (1).png"
import Ch9q9a2 from "./Phyquestions/Chapter-9/9 (2).png"
import Ch9q9a3 from "./Phyquestions/Chapter-9/9 (3).png"
import Ch9q9a4 from "./Phyquestions/Chapter-9/9 (4).png"

import Ch9q10 from "./Phyquestions/Chapter-9/10.png"
import Ch9q10a1 from "./Phyquestions/Chapter-9/10 (1).png"
import Ch9q10a2 from "./Phyquestions/Chapter-9/10 (2).png"
import Ch9q10a3 from "./Phyquestions/Chapter-9/10 (3).png"
import Ch9q10a4 from "./Phyquestions/Chapter-9/10 (4).png"

import Ch9q11 from "./Phyquestions/Chapter-9/11.png"
import Ch9q11a1 from "./Phyquestions/Chapter-9/11 (1).png"
import Ch9q11a2 from "./Phyquestions/Chapter-9/11 (2).png"
import Ch9q11a3 from "./Phyquestions/Chapter-9/11 (3).png"
import Ch9q11a4 from "./Phyquestions/Chapter-9/11 (4).png"

import Ch9q12 from "./Phyquestions/Chapter-9/12.png"
import Ch9q12a1 from "./Phyquestions/Chapter-9/12 (1).png"
import Ch9q12a2 from "./Phyquestions/Chapter-9/12 (2).png"
import Ch9q12a3 from "./Phyquestions/Chapter-9/12 (3).png"
import Ch9q12a4 from "./Phyquestions/Chapter-9/12 (4).png"

import Ch9q13 from "./Phyquestions/Chapter-9/13.png"
import Ch9q13a1 from "./Phyquestions/Chapter-9/13 (1).png"
import Ch9q13a2 from "./Phyquestions/Chapter-9/13 (2).png"
import Ch9q13a3 from "./Phyquestions/Chapter-9/13 (3).png"
import Ch9q13a4 from "./Phyquestions/Chapter-9/13 (4).png"

import Ch9q14 from "./Phyquestions/Chapter-9/14.png"
import Ch9q14a1 from "./Phyquestions/Chapter-9/14 (1).png"
import Ch9q14a2 from "./Phyquestions/Chapter-9/14 (2).png"
import Ch9q14a3 from "./Phyquestions/Chapter-9/14 (3).png"
import Ch9q14a4 from "./Phyquestions/Chapter-9/14 (4).png"

import Ch9q15 from "./Phyquestions/Chapter-9/15.png"
import Ch9q15a1 from "./Phyquestions/Chapter-9/15 (1).png"
import Ch9q15a2 from "./Phyquestions/Chapter-9/15 (2).png"
import Ch9q15a3 from "./Phyquestions/Chapter-9/15 (3).png"
import Ch9q15a4 from "./Phyquestions/Chapter-9/15 (4).png"



import Ch10q1 from "./Phyquestions/Chapter-10/1.png"
import Ch10q1a1 from "./Phyquestions/Chapter-10/1 (1).png"
import Ch10q1a2 from "./Phyquestions/Chapter-10/1 (2).png"
import Ch10q1a3 from "./Phyquestions/Chapter-10/1 (3).png"
import Ch10q1a4 from "./Phyquestions/Chapter-10/1 (4).png"



import Ch10q2 from "./Phyquestions/Chapter-10/2.png"
import Ch10q2a1 from "./Phyquestions/Chapter-10/2 (1).png"
import Ch10q2a2 from "./Phyquestions/Chapter-10/2 (2).png"
import Ch10q2a3 from "./Phyquestions/Chapter-10/2 (3).png"
import Ch10q2a4 from "./Phyquestions/Chapter-10/2 (4).png"

import Ch10q3 from "./Phyquestions/Chapter-10/3.png"
import Ch10q3a1 from "./Phyquestions/Chapter-10/3 (1).png"
import Ch10q3a2 from "./Phyquestions/Chapter-10/3 (2).png"
import Ch10q3a3 from "./Phyquestions/Chapter-10/3 (3).png"
import Ch10q3a4 from "./Phyquestions/Chapter-10/3 (4).png"

import Ch10q4 from "./Phyquestions/Chapter-10/4.png"
import Ch10q4a1 from "./Phyquestions/Chapter-10/4 (1).png"
import Ch10q4a2 from "./Phyquestions/Chapter-10/4 (2).png"
import Ch10q4a3 from "./Phyquestions/Chapter-10/4 (3).png"
import Ch10q4a4 from "./Phyquestions/Chapter-10/4 (4).png"

import Ch10q5 from "./Phyquestions/Chapter-10/5.png"
import Ch10q5a1 from "./Phyquestions/Chapter-10/5 (1).png"
import Ch10q5a2 from "./Phyquestions/Chapter-10/5 (2).png"
import Ch10q5a3 from "./Phyquestions/Chapter-10/5 (3).png"
import Ch10q5a4 from "./Phyquestions/Chapter-10/5 (4).png"

import Ch10q6 from "./Phyquestions/Chapter-10/6.png"
import Ch10q6a1 from "./Phyquestions/Chapter-10/6 (1).png"
import Ch10q6a2 from "./Phyquestions/Chapter-10/6 (2).png"
import Ch10q6a3 from "./Phyquestions/Chapter-10/6 (3).png"
import Ch10q6a4 from "./Phyquestions/Chapter-10/6 (4).png"

import Ch10q7 from "./Phyquestions/Chapter-10/7.png"
import Ch10q7a1 from "./Phyquestions/Chapter-10/7 (1).png"
import Ch10q7a2 from "./Phyquestions/Chapter-10/7 (2).png"
import Ch10q7a3 from "./Phyquestions/Chapter-10/7 (3).png"
import Ch10q7a4 from "./Phyquestions/Chapter-10/7 (4).png"

import Ch10q8 from "./Phyquestions/Chapter-10/8.png"
import Ch10q8a1 from "./Phyquestions/Chapter-10/8 (1).png"
import Ch10q8a2 from "./Phyquestions/Chapter-10/8 (2).png"
import Ch10q8a3 from "./Phyquestions/Chapter-10/8 (3).png"
import Ch10q8a4 from "./Phyquestions/Chapter-10/8 (4).png"

import Ch10q9 from "./Phyquestions/Chapter-10/9.png"
import Ch10q9a1 from "./Phyquestions/Chapter-10/9 (1).png"
import Ch10q9a2 from "./Phyquestions/Chapter-10/9 (2).png"
import Ch10q9a3 from "./Phyquestions/Chapter-10/9 (3).png"
import Ch10q9a4 from "./Phyquestions/Chapter-10/9 (4).png"

import Ch10q10 from "./Phyquestions/Chapter-10/10.png"
import Ch10q10a1 from "./Phyquestions/Chapter-10/10 (1).png"
import Ch10q10a2 from "./Phyquestions/Chapter-10/10 (2).png"
import Ch10q10a3 from "./Phyquestions/Chapter-10/10 (3).png"
import Ch10q10a4 from "./Phyquestions/Chapter-10/10 (4).png"

import Ch10q11 from "./Phyquestions/Chapter-10/11.png"
import Ch10q11a1 from "./Phyquestions/Chapter-10/11 (1).png"
import Ch10q11a2 from "./Phyquestions/Chapter-10/11 (2).png"
import Ch10q11a3 from "./Phyquestions/Chapter-10/11 (3).png"
import Ch10q11a4 from "./Phyquestions/Chapter-10/11 (4).png"

import Ch10q12 from "./Phyquestions/Chapter-10/12.png"
import Ch10q12a1 from "./Phyquestions/Chapter-10/12 (1).png"
import Ch10q12a2 from "./Phyquestions/Chapter-10/12 (2).png"
import Ch10q12a3 from "./Phyquestions/Chapter-10/12 (3).png"
import Ch10q12a4 from "./Phyquestions/Chapter-10/12 (4).png"
import Ch10q12image  from "./Phyquestions/Chapter-10/12-image.png"

import Ch10q13 from "./Phyquestions/Chapter-10/13.png"
import Ch10q13a1 from "./Phyquestions/Chapter-10/13 (1).png"
import Ch10q13a2 from "./Phyquestions/Chapter-10/13 (2).png"
import Ch10q13a3 from "./Phyquestions/Chapter-10/13 (3).png"
import Ch10q13a4 from "./Phyquestions/Chapter-10/13 (4).png"
import Ch10q13image  from "./Phyquestions/Chapter-10/13-image.png"

import Ch10q14 from "./Phyquestions/Chapter-10/14.png"
import Ch10q14a1 from "./Phyquestions/Chapter-10/14 (1).png"
import Ch10q14a2 from "./Phyquestions/Chapter-10/14 (2).png"
import Ch10q14a3 from "./Phyquestions/Chapter-10/14 (3).png"
import Ch10q14a4 from "./Phyquestions/Chapter-10/14 (4).png"

import Ch10q15 from "./Phyquestions/Chapter-10/15.png"
import Ch10q15a1 from "./Phyquestions/Chapter-10/15 (1).png"
import Ch10q15a2 from "./Phyquestions/Chapter-10/15 (2).png"
import Ch10q15a3 from "./Phyquestions/Chapter-10/15 (3).png"
import Ch10q15a4 from "./Phyquestions/Chapter-10/15 (4).png"




import Ch11q1 from "./Phyquestions/Chapter-11/1.png"
import Ch11q1a1 from "./Phyquestions/Chapter-11/1 (1).png"
import Ch11q1a2 from "./Phyquestions/Chapter-11/1 (2).png"
import Ch11q1a3 from "./Phyquestions/Chapter-11/1 (3).png"
import Ch11q1a4 from "./Phyquestions/Chapter-11/1 (4).png"



import Ch11q2 from "./Phyquestions/Chapter-11/2.png"
import Ch11q2a1 from "./Phyquestions/Chapter-11/2 (1).png"
import Ch11q2a2 from "./Phyquestions/Chapter-11/2 (2).png"
import Ch11q2a3 from "./Phyquestions/Chapter-11/2 (3).png"
import Ch11q2a4 from "./Phyquestions/Chapter-11/2 (4).png"

import Ch11q3 from "./Phyquestions/Chapter-11/3.png"
import Ch11q3a1 from "./Phyquestions/Chapter-11/3 (1).png"
import Ch11q3a2 from "./Phyquestions/Chapter-11/3 (2).png"
import Ch11q3a3 from "./Phyquestions/Chapter-11/3 (3).png"
import Ch11q3a4 from "./Phyquestions/Chapter-11/3 (4).png"

import Ch11q4 from "./Phyquestions/Chapter-11/4.png"
import Ch11q4a1 from "./Phyquestions/Chapter-11/4 (1).png"
import Ch11q4a2 from "./Phyquestions/Chapter-11/4 (2).png"
import Ch11q4a3 from "./Phyquestions/Chapter-11/4 (3).png"
import Ch11q4a4 from "./Phyquestions/Chapter-11/4 (4).png"

import Ch11q5 from "./Phyquestions/Chapter-11/5.png"
import Ch11q5a1 from "./Phyquestions/Chapter-11/5 (1).png"
import Ch11q5a2 from "./Phyquestions/Chapter-11/5 (2).png"
import Ch11q5a3 from "./Phyquestions/Chapter-11/5 (3).png"
import Ch11q5a4 from "./Phyquestions/Chapter-11/5 (4).png"

import Ch11q6 from "./Phyquestions/Chapter-11/6.png"
import Ch11q6a1 from "./Phyquestions/Chapter-11/6 (1).png"
import Ch11q6a2 from "./Phyquestions/Chapter-11/6 (2).png"
import Ch11q6a3 from "./Phyquestions/Chapter-11/6 (3).png"
import Ch11q6a4 from "./Phyquestions/Chapter-11/6 (4).png"

import Ch11q7 from "./Phyquestions/Chapter-11/7.png"
import Ch11q7a1 from "./Phyquestions/Chapter-11/7 (1).png"
import Ch11q7a2 from "./Phyquestions/Chapter-11/7 (2).png"
import Ch11q7a3 from "./Phyquestions/Chapter-11/7 (3).png"
import Ch11q7a4 from "./Phyquestions/Chapter-11/7 (4).png"

import Ch11q8 from "./Phyquestions/Chapter-11/8.png"
import Ch11q8a1 from "./Phyquestions/Chapter-11/8 (1).png"
import Ch11q8a2 from "./Phyquestions/Chapter-11/8 (2).png"
import Ch11q8a3 from "./Phyquestions/Chapter-11/8 (3).png"
import Ch11q8a4 from "./Phyquestions/Chapter-11/8 (4).png"

import Ch11q9 from "./Phyquestions/Chapter-11/9.png"
import Ch11q9a1 from "./Phyquestions/Chapter-11/9 (1).png"
import Ch11q9a2 from "./Phyquestions/Chapter-11/9 (2).png"
import Ch11q9a3 from "./Phyquestions/Chapter-11/9 (3).png"
import Ch11q9a4 from "./Phyquestions/Chapter-11/9 (4).png"

import Ch11q10 from "./Phyquestions/Chapter-11/10.png"
import Ch11q10a1 from "./Phyquestions/Chapter-11/10 (1).png"
import Ch11q10a2 from "./Phyquestions/Chapter-11/10 (2).png"
import Ch11q10a3 from "./Phyquestions/Chapter-11/10 (3).png"
import Ch11q10a4 from "./Phyquestions/Chapter-11/10 (4).png"




























export const newData = {
    chapters: [
      {
        chapter: "chapter-6",
        questions: [
          {
            question: Ch6q1,
            options: [
              Ch6q1a1,
              Ch6q1a2,
              Ch6q1a3,
              Ch6q1a4
            ],
           
            answer: Ch6q1a1,
            
          },
          {
            question: Ch6q2,
            options: [
              Ch6q2a1,
              Ch6q2a2,
              Ch6q2a3,
              Ch6q2a4
            ],
            answer: Ch6q2a2,
            
          },
          {
            question: Ch6q3,
            options: [
              Ch6q3a1,
              Ch6q3a2,
              Ch6q3a3,
              Ch6q3a4
            ],
           
            answer: Ch6q3a4,
            
           
          },
          {
            question: Ch6q4,
            options: [
              Ch6q4a1,
              Ch6q4a2,
              Ch6q4a3,
              Ch6q4a4
            ],
            answer:  Ch6q4a1,
            
          },
          {
            question: Ch6q5,
            options: [
              Ch6q5a1,
              Ch6q5a2,
              Ch6q5a3,
              Ch6q5a4
            ],
            
            answer:  Ch6q5a2,
            option_mode: "imagey"
            
          },
    
          {
            question: Ch6q6,
            options: [
              Ch6q6a1,
              Ch6q6a2,
              Ch6q6a3,
              Ch6q6a4
            ],
           
            answer:  Ch6q6a3,
            
            
          },
    
          {
            question: Ch6q7,
            options: [
              Ch6q7a1,
              Ch6q7a2,
              Ch6q7a3,
              Ch6q7a4
            ],
            answer: Ch6q7a4,
            
          },
          {
            question: Ch6q8,
            options: [
              Ch6q8a1,
              Ch6q8a2,
              Ch6q8a3,
              Ch6q8a4
            ],
            
            answer: Ch6q8a2,
            
          },
          {
            question: Ch6q9,
            options: [
              Ch6q9a1,
              Ch6q9a2,
              Ch6q9a3,
              Ch6q9a4
            ],
            answer: Ch6q9a3,
            
           
          },
          {
            question: Ch6q10,
            options: [
              Ch6q10a1,
              Ch6q10a2,
              Ch6q10a3,
              Ch6q10a4
            ],
            answer: Ch6q10a4,
            
           
          }
         
        ]
      },


      {
        chapter: "chapter-7",
        questions: [
          {
            question: Ch7q1,
            options: [
              Ch7q1a1,
              Ch7q1a2,
              Ch7q1a3,
              Ch7q1a4
            ],
           
            answer: Ch7q1a4,
            
          },
          {
            question: Ch7q2,
            options: [
              Ch7q2a1,
              Ch7q2a2,
              Ch7q2a3,
              Ch7q2a4
            ],
            answer: Ch7q2a2,
            
          },
          {
            question: Ch7q3,
            options: [
              Ch7q3a1,
              Ch7q3a2,
              Ch7q3a3,
              Ch7q3a4
            ],
           
            answer: Ch7q3a1,
            
            option_mode: "imagey"
          },
          {
            question: Ch7q4,
            options: [
              Ch7q4a1,
              Ch7q4a2,
              Ch7q4a3,
              Ch7q4a4
            ],
            answer:  Ch7q4a3,
            
          },
          {
            question: Ch7q5,
            options: [
              Ch7q5a1,
              Ch7q5a2,
              Ch7q5a3,
              Ch7q5a4
            ],
            
            answer:  Ch7q5a2,
            
          },
    
          {
            question: Ch7q6,
            options: [
              Ch7q6a1,
              Ch7q6a2,
              Ch7q6a3,
              Ch7q6a4
            ],
            
            answer:  Ch7q6a2,
            
            
          },
    
          {
            question: Ch7q7,
            options: [
              Ch7q7a1,
              Ch7q7a2,
              Ch7q7a3,
              Ch7q7a4
            ],
            answer: Ch7q7a1,
            option_mode: "imagey"
            
          },
          {
            question: Ch7q8,
            options: [
              Ch7q8a1,
              Ch7q8a2,
              Ch7q8a3,
              Ch7q8a4
            ],
            
            answer: Ch7q8a2,
            
          },
          {
            question: Ch7q9,
            options: [
              Ch7q9a1,
              Ch7q9a2,
              Ch7q9a3,
              Ch7q9a4
            ],
            answer: Ch7q9a3,
            
            
          },
          {
            question: Ch7q10,
            options: [
              Ch7q10a1,
              Ch7q10a2,
              Ch7q10a3,
              Ch7q10a4
            ],
            answer: Ch7q10a4,
            
         
          }
         
        ]
      },
  
      {
        chapter: "chapter-8",
        questions: [
          {
            question: Ch8q1,
            options: [
              Ch8q1a1,
              Ch8q1a2,
              Ch8q1a3,
              Ch8q1a4
            ],
           
            answer: Ch8q1a4,
            option_mode: "imagey"
            
          },
          {
            question: Ch8q2,
            options: [
              Ch8q2a1,
              Ch8q2a2,
              Ch8q2a3,
              Ch8q2a4
            ],
            answer: Ch8q2a3,
            
          },
          {
            question: Ch8q3,
            options: [
              Ch8q3a1,
              Ch8q3a2,
              Ch8q3a3,
              Ch8q3a4
            ],
            
            answer: Ch8q3a4,
            
           
          },
          {
            question: Ch8q4,
            options: [
              Ch8q4a1,
              Ch8q4a2,
              Ch8q4a3,
              Ch8q4a4
            ],
            answer:  Ch8q4a4,
            option_mode: "imagey"
            
          },
          {
            question: Ch8q5,
            options: [
              Ch8q5a1,
              Ch8q5a2,
              Ch8q5a3,
              Ch8q5a4
            ],
           
            answer:  Ch8q5a2,
            
          },
    
          {
            question: Ch8q6,
            options: [
              Ch8q6a1,
              Ch8q6a2,
              Ch8q6a3,
              Ch8q6a4
            ],
            
            answer:  Ch8q6a4,
            
            option_mode: "imagey"
          },
    
          {
            question: Ch8q7,
            options: [
              Ch8q7a1,
              Ch8q7a2,
              Ch8q7a3,
              Ch8q7a4
            ],
            answer: Ch8q7a2,
            option_mode: "imagey"
            
          },
          {
            question: Ch8q8,
            options: [
              Ch8q8a1,
              Ch8q8a2,
              Ch8q8a3,
              Ch8q8a4
            ],
            
            answer: Ch8q8a2,
            
          },
          {
            question: Ch8q9,
            options: [
              Ch8q9a1,
              Ch8q9a2,
              Ch8q9a3,
              Ch8q9a4
            ],
            answer: Ch8q9a3,
            
            
          },
          {
            question: Ch8q10,
            options: [
              Ch8q10a1,
              Ch8q10a2,
              Ch8q10a3,
              Ch8q10a4
            ],
            answer: Ch8q10a1,
            
         
          },
          {
            question: Ch8q11,
            options: [
              Ch8q11a1,
              Ch8q11a2,
              Ch8q11a3,
              Ch8q11a4
            ],
            answer:  Ch8q11a2,
            
          },
          {
            question: Ch8q12,
            options: [
              Ch8q12a1,
              Ch8q12a2,
              Ch8q12a3,
              Ch8q12a4
            ],
            answer: Ch8q12a3,
            
          },
          {
            question: Ch8q13,
            options: [
              Ch8q13a1,
              Ch8q13a2,
              Ch8q13a3,
              Ch8q13a4
            ],
            answer: Ch8q13a4,
            option_mode: "imagey"
            
          },
          {
            question: Ch8q14,
            options: [
              Ch8q14a1,
              Ch8q14a2,
              Ch8q14a3,
              Ch8q14a4
            ],
            
            answer:Ch8q14a2,
            
          
          },
          {
            question: Ch8q15,
            options: [
              Ch8q15a1,
              Ch8q15a2,
              Ch8q15a3,
              Ch8q15a4
            ],
            answer: Ch8q15a3,
            
          }
        ]
      },

      {
        chapter: "chapter-9",
        questions: [
          {
            question: Ch9q1,
            options: [
              Ch9q1a1,
              Ch9q1a2,
              Ch9q1a3,
              Ch9q1a4
            ],
           
            answer: Ch9q1a2,
            option_mode: "imagey"
            
          },
          {
            question: Ch9q2,
            options: [
              Ch9q2a1,
              Ch9q2a2,
              Ch9q2a3,
              Ch9q2a4
            ],
            answer: Ch9q2a4,
            option_mode: "imagey"
            
          },
          {
            question: Ch9q3,
            options: [
              Ch9q3a1,
              Ch9q3a2,
              Ch9q3a3,
              Ch9q3a4
            ],
      
            answer: Ch9q3a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch9q4,
            options: [
              Ch9q4a1,
              Ch9q4a2,
              Ch9q4a3,
              Ch9q4a4
            ],
            answer:  Ch9q4a3,
            
          },
          {
            question: Ch9q5,
            options: [
              Ch9q5a1,
              Ch9q5a2,
              Ch9q5a3,
              Ch9q5a4
            ],
            
            answer:  Ch9q5a2,
            
          },
    
          {
            question: Ch9q6,
            options: [
              Ch9q6a1,
              Ch9q6a2,
              Ch9q6a3,
              Ch9q6a4
            ],
            
            answer:  Ch9q6a2,
            
          
          },
    
          {
            question: Ch9q7,
            options: [
              Ch9q7a1,
              Ch9q7a2,
              Ch9q7a3,
              Ch9q7a4
            ],
            answer: Ch9q7a4,
            
          },
          {
            question: Ch9q8,
            options: [
              Ch9q8a1,
              Ch9q8a2,
              Ch9q8a3,
              Ch9q8a4
            ],
       
            answer: Ch9q8a2,
            option_mode: "imagey"
            
          },
          {
            question: Ch9q9,
            options: [
              Ch9q9a1,
              Ch9q9a2,
              Ch9q9a3,
              Ch9q9a4
            ],
            answer: Ch9q9a3,
          
          },
          {
            question: Ch9q10,
            options: [
              Ch9q10a1,
              Ch9q10a2,
              Ch9q10a3,
              Ch9q10a4
            ],
            answer: Ch9q10a1,
            
            
          },
          {
            question: Ch9q11,
            options: [
              Ch9q11a1,
              Ch9q11a2,
              Ch9q11a3,
              Ch9q11a4
            ],
            answer:  Ch9q11a2,
            
          },
          {
            question: Ch9q12,
            options: [
              Ch9q12a1,
              Ch9q12a2,
              Ch9q12a3,
              Ch9q12a4
            ],
            answer: Ch9q12a3,
            option_mode: "imagey"
            
          },
          {
            question: Ch9q13,
            options: [
              Ch9q13a1,
              Ch9q13a2,
              Ch9q13a3,
              Ch9q13a4
            ],
            answer: Ch9q13a2,
            option_mode: "imagey"
            
          },
          {
            question: Ch9q14,
            options: [
              Ch9q14a1,
              Ch9q14a2,
              Ch9q14a3,
              Ch9q14a4
            ],
           
            answer:Ch9q14a3,
            
            
          },
          {
            question: Ch9q15,
            options: [
              Ch9q15a1,
              Ch9q15a2,
              Ch9q15a3,
              Ch9q15a4
            ],
            answer: Ch9q15a2,
            option_mode: "imagey"
            
          }
        ]
      },


      {
    chapter: "chapter-10",
    questions: [
      {
        question: Ch10q1,
        options: [
          Ch10q1a1,
          Ch10q1a2,
          Ch10q1a3,
          Ch10q1a4
        ],
       
        answer: Ch10q1a2,
        
      },
      {
        question: Ch10q2,
        options: [
          Ch10q2a1,
          Ch10q2a2,
          Ch10q2a3,
          Ch10q2a4
        ],
        answer: Ch10q2a3,
        option_mode: "imagez"
      },
      {
        question: Ch10q3,
        options: [
          Ch10q3a1,
          Ch10q3a2,
          Ch10q3a3,
          Ch10q3a4
        ],
       
        answer: Ch10q3a2,
        
        option_mode: "imagez"
      },
      {
        question: Ch10q4,
        options: [
          Ch10q4a1,
          Ch10q4a2,
          Ch10q4a3,
          Ch10q4a4
        ],
        answer:  Ch10q4a3,
        
      },
      {
        question: Ch10q5,
        options: [
          Ch10q5a1,
          Ch10q5a2,
          Ch10q5a3,
          Ch10q5a4
        ],
       
        answer:  Ch10q5a4,
        
      },

      {
        question: Ch10q6,
        options: [
          Ch10q6a1,
          Ch10q6a2,
          Ch10q6a3,
          Ch10q6a4
        ],
        
        answer:  Ch10q6a3,
      
      },

      {
        question: Ch10q7,
        options: [
          Ch10q7a1,
          Ch10q7a2,
          Ch10q7a3,
          Ch10q7a4
        ],
        answer: Ch10q7a1,
      
      },
      {
        question: Ch10q8,
        options: [
          Ch10q8a1,
          Ch10q8a2,
          Ch10q8a3,
          Ch10q8a4
        ],
        
        answer: Ch10q8a4,
        
      },
      {
        question: Ch10q9,
        options: [
          Ch10q9a1,
          Ch10q9a2,
          Ch10q9a3,
          Ch10q9a4
        ],
        answer: Ch10q9a4,
      
      },
      {
        question: Ch10q10,
        options: [
          Ch10q10a1,
          Ch10q10a2,
          Ch10q10a3,
          Ch10q10a4
        ],
        answer: Ch10q10a1,
       
      },
      {
        question: Ch10q11,
        options: [
          Ch10q11a1,
          Ch10q11a2,
          Ch10q11a3,
          Ch10q11a4
        ],
        answer:  Ch10q11a1,
        option_mode: "images",
        
        
      },
      {
        question: Ch10q12,
        options: [
          Ch10q12a1,
          Ch10q12a2,
          Ch10q12a3,
          Ch10q12a4
        ],
        answer: Ch10q12a3,
        image:  Ch10q12image,
      
      },
      {
        question: Ch10q13,
        options: [
          Ch10q13a1,
          Ch10q13a2,
          Ch10q13a3,
          Ch10q13a4
        ],
        answer: Ch10q13a1,
        image:  Ch10q13image
       
      },
      {
        question: Ch10q14,
        options: [
          Ch10q14a1,
          Ch10q14a2,
          Ch10q14a3,
          Ch10q14a4
        ],
        
        answer:Ch10q14a2,
       
      },
      {
        question: Ch10q15,
        options: [
          Ch10q15a1,
          Ch10q15a2,
          Ch10q15a3,
          Ch10q15a4
        ],
        answer: Ch10q15a3,
        
      }
    ]
  },



  {
    chapter: "chapter-11",
    questions: [
      {
        question: Ch11q1,
        options: [
          Ch11q1a1,
          Ch11q1a2,
          Ch11q1a3,
          Ch11q1a4
        ],
       
        answer: Ch11q1a2,
        
      },
      {
        question: Ch11q2,
        options: [
          Ch11q2a1,
          Ch11q2a2,
          Ch11q2a3,
          Ch11q2a4
        ],
        answer: Ch11q2a1,
        
      },
      {
        question: Ch11q3,
        options: [
          Ch11q3a1,
          Ch11q3a2,
          Ch11q3a3,
          Ch11q3a4
        ],
        
        answer: Ch11q3a3,
    
      },
      {
        question: Ch11q4,
        options: [
          Ch11q4a1,
          Ch11q4a2,
          Ch11q4a3,
          Ch11q4a4
        ],
        answer:  Ch11q4a2,
        
      },
      {
        question: Ch11q5,
        options: [
          Ch11q5a1,
          Ch11q5a2,
          Ch11q5a3,
          Ch11q5a4
        ],
        
        answer:  Ch11q5a3,
        
      },

      {
        question: Ch11q6,
        options: [
          Ch11q6a1,
          Ch11q6a2,
          Ch11q6a3,
          Ch11q6a4
        ],
        
        answer:  Ch11q6a4,
        
      },

      {
        question: Ch11q7,
        options: [
          Ch11q7a1,
          Ch11q7a2,
          Ch11q7a3,
          Ch11q7a4
        ],
        answer: Ch11q7a1,
       
      },
      {
        question: Ch11q8,
        options: [
          Ch11q8a1,
          Ch11q8a2,
          Ch11q8a3,
          Ch11q8a4
        ],
        
        answer: Ch11q8a3,
    
      },
      {
        question: Ch11q9,
        options: [
          Ch11q9a1,
          Ch11q9a2,
          Ch11q9a3,
          Ch11q9a4
        ],
        answer: Ch11q9a1,
       
      },
      {
        question: Ch11q10,
        options: [
          Ch11q10a1,
          Ch11q10a2,
          Ch11q10a3,
          Ch11q10a4
        ],
        answer: Ch11q10a3,
       
      }
      
    ]
  }
    ]
  }
  