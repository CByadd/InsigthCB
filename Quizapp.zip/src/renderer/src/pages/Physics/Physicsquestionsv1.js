import Ch1q1 from "./Phyquestions/Chapter-1/1.png"
import Ch1q1a1 from "./Phyquestions/Chapter-1/1 (1).png"
import Ch1q1a2 from "./Phyquestions/Chapter-1/1 (2).png"
import Ch1q1a3 from "./Phyquestions/Chapter-1/1 (3).png"
import Ch1q1a4 from "./Phyquestions/Chapter-1/1 (4).png"
import Ch1q1image from "./Phyquestions/Chapter-1/1-image.png"


import Ch1q2 from "./Phyquestions/Chapter-1/2.png"
import Ch1q2a1 from "./Phyquestions/Chapter-1/2 (1).png"
import Ch1q2a2 from "./Phyquestions/Chapter-1/2 (2).png"
import Ch1q2a3 from "./Phyquestions/Chapter-1/2 (3).png"
import Ch1q2a4 from "./Phyquestions/Chapter-1/2 (4).png"

import Ch1q3 from "./Phyquestions/Chapter-1/3.png"
import Ch1q3a1 from "./Phyquestions/Chapter-1/3 (1).png"
import Ch1q3a2 from "./Phyquestions/Chapter-1/3 (2).png"
import Ch1q3a3 from "./Phyquestions/Chapter-1/3 (3).png"
import Ch1q3a4 from "./Phyquestions/Chapter-1/3 (4).png"
import Ch1q3image from "./Phyquestions/Chapter-1/3-image.png"

import Ch1q4 from "./Phyquestions/Chapter-1/4.png"
import Ch1q4a1 from "./Phyquestions/Chapter-1/4 (1).png"
import Ch1q4a2 from "./Phyquestions/Chapter-1/4 (2).png"
import Ch1q4a3 from "./Phyquestions/Chapter-1/4 (3).png"
import Ch1q4a4 from "./Phyquestions/Chapter-1/4 (4).png"

import Ch1q5 from "./Phyquestions/Chapter-1/5.png"
import Ch1q5a1 from "./Phyquestions/Chapter-1/5 (1).png"
import Ch1q5a2 from "./Phyquestions/Chapter-1/5 (2).png"
import Ch1q5a3 from "./Phyquestions/Chapter-1/5 (3).png"
import Ch1q5a4 from "./Phyquestions/Chapter-1/5 (4).png"
import Ch1q5image from "./Phyquestions/Chapter-1/5-image.png"

import Ch1q6 from "./Phyquestions/Chapter-1/6.png"
import Ch1q6a1 from "./Phyquestions/Chapter-1/6 (1).png"
import Ch1q6a2 from "./Phyquestions/Chapter-1/6 (2).png"
import Ch1q6a3 from "./Phyquestions/Chapter-1/6 (3).png"
import Ch1q6a4 from "./Phyquestions/Chapter-1/6 (4).png"
import Ch1q6image from "./Phyquestions/Chapter-1/6-image.png"

import Ch1q7 from "./Phyquestions/Chapter-1/7.png"
import Ch1q7a1 from "./Phyquestions/Chapter-1/7 (1).png"
import Ch1q7a2 from "./Phyquestions/Chapter-1/7 (2).png"
import Ch1q7a3 from "./Phyquestions/Chapter-1/7 (3).png"
import Ch1q7a4 from "./Phyquestions/Chapter-1/7 (4).png"

import Ch1q8 from "./Phyquestions/Chapter-1/8.png"
import Ch1q8a1 from "./Phyquestions/Chapter-1/8 (1).png"
import Ch1q8a2 from "./Phyquestions/Chapter-1/8 (2).png"
import Ch1q8a3 from "./Phyquestions/Chapter-1/8 (3).png"
import Ch1q8a4 from "./Phyquestions/Chapter-1/8 (4).png"

import Ch1q9 from "./Phyquestions/Chapter-1/9.png"
import Ch1q9a1 from "./Phyquestions/Chapter-1/9 (1).png"
import Ch1q9a2 from "./Phyquestions/Chapter-1/9 (2).png"
import Ch1q9a3 from "./Phyquestions/Chapter-1/9 (3).png"
import Ch1q9a4 from "./Phyquestions/Chapter-1/9 (4).png"

import Ch1q10 from "./Phyquestions/Chapter-1/10.png"
import Ch1q10a1 from "./Phyquestions/Chapter-1/10 (1).png"
import Ch1q10a2 from "./Phyquestions/Chapter-1/10 (2).png"
import Ch1q10a3 from "./Phyquestions/Chapter-1/10 (3).png"
import Ch1q10a4 from "./Phyquestions/Chapter-1/10 (4).png"

import Ch1q11 from "./Phyquestions/Chapter-1/11.png"
import Ch1q11a1 from "./Phyquestions/Chapter-1/11 (1).png"
import Ch1q11a2 from "./Phyquestions/Chapter-1/11 (2).png"
import Ch1q11a3 from "./Phyquestions/Chapter-1/11 (3).png"
import Ch1q11a4 from "./Phyquestions/Chapter-1/11 (4).png"

import Ch1q12 from "./Phyquestions/Chapter-1/12.png"
import Ch1q12a1 from "./Phyquestions/Chapter-1/12 (1).png"
import Ch1q12a2 from "./Phyquestions/Chapter-1/12 (2).png"
import Ch1q12a3 from "./Phyquestions/Chapter-1/12 (3).png"
import Ch1q12a4 from "./Phyquestions/Chapter-1/12 (4).png"

import Ch1q13 from "./Phyquestions/Chapter-1/13.png"
import Ch1q13a1 from "./Phyquestions/Chapter-1/13 (1).png"
import Ch1q13a2 from "./Phyquestions/Chapter-1/13 (2).png"
import Ch1q13a3 from "./Phyquestions/Chapter-1/13 (3).png"
import Ch1q13a4 from "./Phyquestions/Chapter-1/13 (4).png"

import Ch1q14 from "./Phyquestions/Chapter-1/14.png"
import Ch1q14a1 from "./Phyquestions/Chapter-1/14 (1).png"
import Ch1q14a2 from "./Phyquestions/Chapter-1/14 (2).png"
import Ch1q14a3 from "./Phyquestions/Chapter-1/14 (3).png"
import Ch1q14a4 from "./Phyquestions/Chapter-1/14 (4).png"
import Ch1q14image from "./Phyquestions/Chapter-1/14-image.png"

import Ch1q15 from "./Phyquestions/Chapter-1/15.png"
import Ch1q15a1 from "./Phyquestions/Chapter-1/15 (1).png"
import Ch1q15a2 from "./Phyquestions/Chapter-1/15 (2).png"
import Ch1q15a3 from "./Phyquestions/Chapter-1/15 (3).png"
import Ch1q15a4 from "./Phyquestions/Chapter-1/15 (4).png"



import Ch2q1 from "./Phyquestions/Chapter-2/1.png"
import Ch2q1a1 from "./Phyquestions/Chapter-2/1 (1).png"
import Ch2q1a2 from "./Phyquestions/Chapter-2/1 (2).png"
import Ch2q1a3 from "./Phyquestions/Chapter-2/1 (3).png"
import Ch2q1a4 from "./Phyquestions/Chapter-2/1 (4).png"
import Ch2q1image from "./Phyquestions/Chapter-2/1-image.png"



import Ch2q2 from "./Phyquestions/Chapter-2/2.png"
import Ch2q2a1 from "./Phyquestions/Chapter-2/2 (1).png"
import Ch2q2a2 from "./Phyquestions/Chapter-2/2 (2).png"
import Ch2q2a3 from "./Phyquestions/Chapter-2/2 (3).png"
import Ch2q2a4 from "./Phyquestions/Chapter-2/2 (4).png"
import Ch2q2image from "./Phyquestions/Chapter-2/2-image.png"

import Ch2q3 from "./Phyquestions/Chapter-2/3.png"
import Ch2q3a1 from "./Phyquestions/Chapter-2/3 (1).png"
import Ch2q3a2 from "./Phyquestions/Chapter-2/3 (2).png"
import Ch2q3a3 from "./Phyquestions/Chapter-2/3 (3).png"
import Ch2q3a4 from "./Phyquestions/Chapter-2/3 (4).png"

import Ch2q4 from "./Phyquestions/Chapter-2/4.png"
import Ch2q4a1 from "./Phyquestions/Chapter-2/4 (1).png"
import Ch2q4a2 from "./Phyquestions/Chapter-2/4 (2).png"
import Ch2q4a3 from "./Phyquestions/Chapter-2/4 (3).png"
import Ch2q4a4 from "./Phyquestions/Chapter-2/4 (4).png"

import Ch2q5 from "./Phyquestions/Chapter-2/5.png"
import Ch2q5a1 from "./Phyquestions/Chapter-2/5 (1).png"
import Ch2q5a2 from "./Phyquestions/Chapter-2/5 (2).png"
import Ch2q5a3 from "./Phyquestions/Chapter-2/5 (3).png"
import Ch2q5a4 from "./Phyquestions/Chapter-2/5 (4).png"
import Ch2q5image from "./Phyquestions/Chapter-2/5-image.png"

import Ch2q6 from "./Phyquestions/Chapter-2/6.png"
import Ch2q6a1 from "./Phyquestions/Chapter-2/6 (1).png"
import Ch2q6a2 from "./Phyquestions/Chapter-2/6 (2).png"
import Ch2q6a3 from "./Phyquestions/Chapter-2/6 (3).png"
import Ch2q6a4 from "./Phyquestions/Chapter-2/6 (4).png"

import Ch2q7 from "./Phyquestions/Chapter-2/7.png"
import Ch2q7a1 from "./Phyquestions/Chapter-2/7 (1).png"
import Ch2q7a2 from "./Phyquestions/Chapter-2/7 (2).png"
import Ch2q7a3 from "./Phyquestions/Chapter-2/7 (3).png"
import Ch2q7a4 from "./Phyquestions/Chapter-2/7 (4).png"

import Ch2q8 from "./Phyquestions/Chapter-2/8.png"
import Ch2q8a1 from "./Phyquestions/Chapter-2/8 (1).png"
import Ch2q8a2 from "./Phyquestions/Chapter-2/8 (2).png"
import Ch2q8a3 from "./Phyquestions/Chapter-2/8 (3).png"
import Ch2q8a4 from "./Phyquestions/Chapter-2/8 (4).png"

import Ch2q9 from "./Phyquestions/Chapter-2/9.png"
import Ch2q9a1 from "./Phyquestions/Chapter-2/9 (1).png"
import Ch2q9a2 from "./Phyquestions/Chapter-2/9 (2).png"
import Ch2q9a3 from "./Phyquestions/Chapter-2/9 (3).png"
import Ch2q9a4 from "./Phyquestions/Chapter-2/9 (4).png"

import Ch2q10 from "./Phyquestions/Chapter-2/10.png"
import Ch2q10a1 from "./Phyquestions/Chapter-2/10 (1).png"
import Ch2q10a2 from "./Phyquestions/Chapter-2/10 (2).png"
import Ch2q10a3 from "./Phyquestions/Chapter-2/10 (3).png"
import Ch2q10a4 from "./Phyquestions/Chapter-2/10 (4).png"

import Ch2q11 from "./Phyquestions/Chapter-2/11.png"
import Ch2q11a1 from "./Phyquestions/Chapter-2/11 (1).png"
import Ch2q11a2 from "./Phyquestions/Chapter-2/11 (2).png"
import Ch2q11a3 from "./Phyquestions/Chapter-2/11 (3).png"
import Ch2q11a4 from "./Phyquestions/Chapter-2/11 (4).png"
import Ch2q11image from "./Phyquestions/Chapter-2/11-image.png"

import Ch2q12 from "./Phyquestions/Chapter-2/12.png"
import Ch2q12a1 from "./Phyquestions/Chapter-2/12 (1).png"
import Ch2q12a2 from "./Phyquestions/Chapter-2/12 (2).png"
import Ch2q12a3 from "./Phyquestions/Chapter-2/12 (3).png"
import Ch2q12a4 from "./Phyquestions/Chapter-2/12 (4).png"

import Ch2q13 from "./Phyquestions/Chapter-2/13.png"
import Ch2q13a1 from "./Phyquestions/Chapter-2/13 (1).png"
import Ch2q13a2 from "./Phyquestions/Chapter-2/13 (2).png"
import Ch2q13a3 from "./Phyquestions/Chapter-2/13 (3).png"
import Ch2q13a4 from "./Phyquestions/Chapter-2/13 (4).png"

import Ch2q14 from "./Phyquestions/Chapter-2/14.png"
import Ch2q14a1 from "./Phyquestions/Chapter-2/14 (1).png"
import Ch2q14a2 from "./Phyquestions/Chapter-2/14 (2).png"
import Ch2q14a3 from "./Phyquestions/Chapter-2/14 (3).png"
import Ch2q14a4 from "./Phyquestions/Chapter-2/14 (4).png"

import Ch2q15 from "./Phyquestions/Chapter-2/15.png"
import Ch2q15a1 from "./Phyquestions/Chapter-2/15 (1).png"
import Ch2q15a2 from "./Phyquestions/Chapter-2/15 (2).png"
import Ch2q15a3 from "./Phyquestions/Chapter-2/15 (3).png"
import Ch2q15a4 from "./Phyquestions/Chapter-2/15 (4).png"



import Ch3q1 from "./Phyquestions/Chapter-3/1.png"
import Ch3q1a1 from "./Phyquestions/Chapter-3/1 (1).png"
import Ch3q1a2 from "./Phyquestions/Chapter-3/1 (2).png"
import Ch3q1a3 from "./Phyquestions/Chapter-3/1 (3).png"
import Ch3q1a4 from "./Phyquestions/Chapter-3/1 (4).png"
import Ch3q1image from "./Phyquestions/Chapter-3/1-image.png"



import Ch3q2 from "./Phyquestions/Chapter-3/2.png"
import Ch3q2a1 from "./Phyquestions/Chapter-3/2 (1).png"
import Ch3q2a2 from "./Phyquestions/Chapter-3/2 (2).png"
import Ch3q2a3 from "./Phyquestions/Chapter-3/2 (3).png"
import Ch3q2a4 from "./Phyquestions/Chapter-3/2 (4).png"
import Ch3q2image from "./Phyquestions/Chapter-3/2-image.png"

import Ch3q3 from "./Phyquestions/Chapter-3/3.png"
import Ch3q3a1 from "./Phyquestions/Chapter-3/3 (1).png"
import Ch3q3a2 from "./Phyquestions/Chapter-3/3 (2).png"
import Ch3q3a3 from "./Phyquestions/Chapter-3/3 (3).png"
import Ch3q3a4 from "./Phyquestions/Chapter-3/3 (4).png"

import Ch3q4 from "./Phyquestions/Chapter-3/4.png"
import Ch3q4a1 from "./Phyquestions/Chapter-3/4 (1).png"
import Ch3q4a2 from "./Phyquestions/Chapter-3/4 (2).png"
import Ch3q4a3 from "./Phyquestions/Chapter-3/4 (3).png"
import Ch3q4a4 from "./Phyquestions/Chapter-3/4 (4).png"

import Ch3q5 from "./Phyquestions/Chapter-3/5.png"
import Ch3q5a1 from "./Phyquestions/Chapter-3/5 (1).png"
import Ch3q5a2 from "./Phyquestions/Chapter-3/5 (2).png"
import Ch3q5a3 from "./Phyquestions/Chapter-3/5 (3).png"
import Ch3q5a4 from "./Phyquestions/Chapter-3/5 (4).png"

import Ch3q6 from "./Phyquestions/Chapter-3/6.png"
import Ch3q6a1 from "./Phyquestions/Chapter-3/6 (1).png"
import Ch3q6a2 from "./Phyquestions/Chapter-3/6 (2).png"
import Ch3q6a3 from "./Phyquestions/Chapter-3/6 (3).png"
import Ch3q6a4 from "./Phyquestions/Chapter-3/6 (4).png"

import Ch3q7 from "./Phyquestions/Chapter-3/7.png"
import Ch3q7a1 from "./Phyquestions/Chapter-3/7 (1).png"
import Ch3q7a2 from "./Phyquestions/Chapter-3/7 (2).png"
import Ch3q7a3 from "./Phyquestions/Chapter-3/7 (3).png"
import Ch3q7a4 from "./Phyquestions/Chapter-3/7 (4).png"
import Ch3q7image from "./Phyquestions/Chapter-3/7-image.png"

import Ch3q8 from "./Phyquestions/Chapter-3/8.png"
import Ch3q8a1 from "./Phyquestions/Chapter-3/8 (1).png"
import Ch3q8a2 from "./Phyquestions/Chapter-3/8 (2).png"
import Ch3q8a3 from "./Phyquestions/Chapter-3/8 (3).png"
import Ch3q8a4 from "./Phyquestions/Chapter-3/8 (4).png"

import Ch3q9 from "./Phyquestions/Chapter-3/9.png"
import Ch3q9a1 from "./Phyquestions/Chapter-3/9 (1).png"
import Ch3q9a2 from "./Phyquestions/Chapter-3/9 (2).png"
import Ch3q9a3 from "./Phyquestions/Chapter-3/9 (3).png"
import Ch3q9a4 from "./Phyquestions/Chapter-3/9 (4).png"
import Ch3q9image from "./Phyquestions/Chapter-3/9-image.png"

import Ch3q10 from "./Phyquestions/Chapter-3/10.png"
import Ch3q10a1 from "./Phyquestions/Chapter-3/10 (1).png"
import Ch3q10a2 from "./Phyquestions/Chapter-3/10 (2).png"
import Ch3q10a3 from "./Phyquestions/Chapter-3/10 (3).png"
import Ch3q10a4 from "./Phyquestions/Chapter-3/10 (4).png"

import Ch3q11 from "./Phyquestions/Chapter-3/11.png"
import Ch3q11a1 from "./Phyquestions/Chapter-3/11 (1).png"
import Ch3q11a2 from "./Phyquestions/Chapter-3/11 (2).png"
import Ch3q11a3 from "./Phyquestions/Chapter-3/11 (3).png"
import Ch3q11a4 from "./Phyquestions/Chapter-3/11 (4).png"

import Ch3q12 from "./Phyquestions/Chapter-3/12.png"
import Ch3q12a1 from "./Phyquestions/Chapter-3/12 (1).png"
import Ch3q12a2 from "./Phyquestions/Chapter-3/12 (2).png"
import Ch3q12a3 from "./Phyquestions/Chapter-3/12 (3).png"
import Ch3q12a4 from "./Phyquestions/Chapter-3/12 (4).png"

import Ch3q13 from "./Phyquestions/Chapter-3/13.png"
import Ch3q13a1 from "./Phyquestions/Chapter-3/13 (1).png"
import Ch3q13a2 from "./Phyquestions/Chapter-3/13 (2).png"
import Ch3q13a3 from "./Phyquestions/Chapter-3/13 (3).png"
import Ch3q13a4 from "./Phyquestions/Chapter-3/13 (4).png"

import Ch3q14 from "./Phyquestions/Chapter-3/14.png"
import Ch3q14a1 from "./Phyquestions/Chapter-3/14 (1).png"
import Ch3q14a2 from "./Phyquestions/Chapter-3/14 (2).png"
import Ch3q14a3 from "./Phyquestions/Chapter-3/14 (3).png"
import Ch3q14a4 from "./Phyquestions/Chapter-3/14 (4).png"

import Ch3q15 from "./Phyquestions/Chapter-3/15.png"
import Ch3q15a1 from "./Phyquestions/Chapter-3/15 (1).png"
import Ch3q15a2 from "./Phyquestions/Chapter-3/15 (2).png"
import Ch3q15a3 from "./Phyquestions/Chapter-3/15 (3).png"
import Ch3q15a4 from "./Phyquestions/Chapter-3/15 (4).png"






import Ch4q1 from "./Phyquestions/Chapter-4/1.png"
import Ch4q1a1 from "./Phyquestions/Chapter-4/1 (1).png"
import Ch4q1a2 from "./Phyquestions/Chapter-4/1 (2).png"
import Ch4q1a3 from "./Phyquestions/Chapter-4/1 (3).png"
import Ch4q1a4 from "./Phyquestions/Chapter-4/1 (4).png"
import Ch4q1image from "./Phyquestions/Chapter-4/1-image.png"



import Ch4q2 from "./Phyquestions/Chapter-4/2.png"
import Ch4q2a1 from "./Phyquestions/Chapter-4/2 (1).png"
import Ch4q2a2 from "./Phyquestions/Chapter-4/2 (2).png"
import Ch4q2a3 from "./Phyquestions/Chapter-4/2 (3).png"
import Ch4q2a4 from "./Phyquestions/Chapter-4/2 (4).png"
import Ch4q2image from "./Phyquestions/Chapter-4/2-image.png"

import Ch4q3 from "./Phyquestions/Chapter-4/3.png"
import Ch4q3a1 from "./Phyquestions/Chapter-4/3 (1).png"
import Ch4q3a2 from "./Phyquestions/Chapter-4/3 (2).png"
import Ch4q3a3 from "./Phyquestions/Chapter-4/3 (3).png"
import Ch4q3a4 from "./Phyquestions/Chapter-4/3 (4).png"

import Ch4q4 from "./Phyquestions/Chapter-4/4.png"
import Ch4q4a1 from "./Phyquestions/Chapter-4/4 (1).png"
import Ch4q4a2 from "./Phyquestions/Chapter-4/4 (2).png"
import Ch4q4a3 from "./Phyquestions/Chapter-4/4 (3).png"
import Ch4q4a4 from "./Phyquestions/Chapter-4/4 (4).png"

import Ch4q5 from "./Phyquestions/Chapter-4/5.png"
import Ch4q5a1 from "./Phyquestions/Chapter-4/5 (1).png"
import Ch4q5a2 from "./Phyquestions/Chapter-4/5 (2).png"
import Ch4q5a3 from "./Phyquestions/Chapter-4/5 (3).png"
import Ch4q5a4 from "./Phyquestions/Chapter-4/5 (4).png"
import Ch4q5image from "./Phyquestions/Chapter-4/5-image.png"

import Ch4q6 from "./Phyquestions/Chapter-4/6.png"
import Ch4q6a1 from "./Phyquestions/Chapter-4/6 (1).png"
import Ch4q6a2 from "./Phyquestions/Chapter-4/6 (2).png"
import Ch4q6a3 from "./Phyquestions/Chapter-4/6 (3).png"
import Ch4q6a4 from "./Phyquestions/Chapter-4/6 (4).png"

import Ch4q7 from "./Phyquestions/Chapter-4/7.png"
import Ch4q7a1 from "./Phyquestions/Chapter-4/7 (1).png"
import Ch4q7a2 from "./Phyquestions/Chapter-4/7 (2).png"
import Ch4q7a3 from "./Phyquestions/Chapter-4/7 (3).png"
import Ch4q7a4 from "./Phyquestions/Chapter-4/7 (4).png"

import Ch4q8 from "./Phyquestions/Chapter-4/8.png"
import Ch4q8a1 from "./Phyquestions/Chapter-4/8 (1).png"
import Ch4q8a2 from "./Phyquestions/Chapter-4/8 (2).png"
import Ch4q8a3 from "./Phyquestions/Chapter-4/8 (3).png"
import Ch4q8a4 from "./Phyquestions/Chapter-4/8 (4).png"

import Ch4q9 from "./Phyquestions/Chapter-4/9.png"
import Ch4q9a1 from "./Phyquestions/Chapter-4/9 (1).png"
import Ch4q9a2 from "./Phyquestions/Chapter-4/9 (2).png"
import Ch4q9a3 from "./Phyquestions/Chapter-4/9 (3).png"
import Ch4q9a4 from "./Phyquestions/Chapter-4/9 (4).png"

import Ch4q10 from "./Phyquestions/Chapter-4/10.png"
import Ch4q10a1 from "./Phyquestions/Chapter-4/10 (1).png"
import Ch4q10a2 from "./Phyquestions/Chapter-4/10 (2).png"
import Ch4q10a3 from "./Phyquestions/Chapter-4/10 (3).png"
import Ch4q10a4 from "./Phyquestions/Chapter-4/10 (4).png"

import Ch4q11 from "./Phyquestions/Chapter-4/11.png"
import Ch4q11a1 from "./Phyquestions/Chapter-4/11 (1).png"
import Ch4q11a2 from "./Phyquestions/Chapter-4/11 (2).png"
import Ch4q11a3 from "./Phyquestions/Chapter-4/11 (3).png"
import Ch4q11a4 from "./Phyquestions/Chapter-4/11 (4).png"

import Ch4q12 from "./Phyquestions/Chapter-4/12.png"
import Ch4q12a1 from "./Phyquestions/Chapter-4/12 (1).png"
import Ch4q12a2 from "./Phyquestions/Chapter-4/12 (2).png"
import Ch4q12a3 from "./Phyquestions/Chapter-4/12 (3).png"
import Ch4q12a4 from "./Phyquestions/Chapter-4/12 (4).png"

import Ch4q13 from "./Phyquestions/Chapter-4/13.png"
import Ch4q13a1 from "./Phyquestions/Chapter-4/13 (1).png"
import Ch4q13a2 from "./Phyquestions/Chapter-4/13 (2).png"
import Ch4q13a3 from "./Phyquestions/Chapter-4/13 (3).png"
import Ch4q13a4 from "./Phyquestions/Chapter-4/13 (4).png"

import Ch4q14 from "./Phyquestions/Chapter-4/14.png"
import Ch4q14a1 from "./Phyquestions/Chapter-4/14 (1).png"
import Ch4q14a2 from "./Phyquestions/Chapter-4/14 (2).png"
import Ch4q14a3 from "./Phyquestions/Chapter-4/14 (3).png"
import Ch4q14a4 from "./Phyquestions/Chapter-4/14 (4).png"

import Ch4q15 from "./Phyquestions/Chapter-4/15.png"
import Ch4q15a1 from "./Phyquestions/Chapter-4/15 (1).png"
import Ch4q15a2 from "./Phyquestions/Chapter-4/15 (2).png"
import Ch4q15a3 from "./Phyquestions/Chapter-4/15 (3).png"
import Ch4q15a4 from "./Phyquestions/Chapter-4/15 (4).png"




import Ch5q1 from "./Phyquestions/Chapter-5/1.png"
import Ch5q1a1 from "./Phyquestions/Chapter-5/1 (1).png"
import Ch5q1a2 from "./Phyquestions/Chapter-5/1 (2).png"
import Ch5q1a3 from "./Phyquestions/Chapter-5/1 (3).png"
import Ch5q1a4 from "./Phyquestions/Chapter-5/1 (4).png"



import Ch5q2 from "./Phyquestions/Chapter-5/2.png"
import Ch5q2a1 from "./Phyquestions/Chapter-5/2 (1).png"
import Ch5q2a2 from "./Phyquestions/Chapter-5/2 (2).png"
import Ch5q2a3 from "./Phyquestions/Chapter-5/2 (3).png"
import Ch5q2a4 from "./Phyquestions/Chapter-5/2 (4).png"

import Ch5q3 from "./Phyquestions/Chapter-5/3.png"
import Ch5q3a1 from "./Phyquestions/Chapter-5/3 (1).png"
import Ch5q3a2 from "./Phyquestions/Chapter-5/3 (2).png"
import Ch5q3a3 from "./Phyquestions/Chapter-5/3 (3).png"
import Ch5q3a4 from "./Phyquestions/Chapter-5/3 (4).png"

import Ch5q4 from "./Phyquestions/Chapter-5/4.png"
import Ch5q4a1 from "./Phyquestions/Chapter-5/4 (1).png"
import Ch5q4a2 from "./Phyquestions/Chapter-5/4 (2).png"
import Ch5q4a3 from "./Phyquestions/Chapter-5/4 (3).png"
import Ch5q4a4 from "./Phyquestions/Chapter-5/4 (4).png"

import Ch5q5 from "./Phyquestions/Chapter-5/5.png"
import Ch5q5a1 from "./Phyquestions/Chapter-5/5 (1).png"
import Ch5q5a2 from "./Phyquestions/Chapter-5/5 (2).png"
import Ch5q5a3 from "./Phyquestions/Chapter-5/5 (3).png"
import Ch5q5a4 from "./Phyquestions/Chapter-5/5 (4).png"


import Ch5q6 from "./Phyquestions/Chapter-5/6.png"
import Ch5q6a1 from "./Phyquestions/Chapter-5/6 (1).png"
import Ch5q6a2 from "./Phyquestions/Chapter-5/6 (2).png"
import Ch5q6a3 from "./Phyquestions/Chapter-5/6 (3).png"
import Ch5q6a4 from "./Phyquestions/Chapter-5/6 (4).png"

import Ch5q7 from "./Phyquestions/Chapter-5/7.png"
import Ch5q7a1 from "./Phyquestions/Chapter-5/7 (1).png"
import Ch5q7a2 from "./Phyquestions/Chapter-5/7 (2).png"
import Ch5q7a3 from "./Phyquestions/Chapter-5/7 (3).png"
import Ch5q7a4 from "./Phyquestions/Chapter-5/7 (4).png"

import Ch5q8 from "./Phyquestions/Chapter-5/8.png"
import Ch5q8a1 from "./Phyquestions/Chapter-5/8 (1).png"
import Ch5q8a2 from "./Phyquestions/Chapter-5/8 (2).png"
import Ch5q8a3 from "./Phyquestions/Chapter-5/8 (3).png"
import Ch5q8a4 from "./Phyquestions/Chapter-5/8 (4).png"

import Ch5q9 from "./Phyquestions/Chapter-5/9.png"
import Ch5q9a1 from "./Phyquestions/Chapter-5/9 (1).png"
import Ch5q9a2 from "./Phyquestions/Chapter-5/9 (2).png"
import Ch5q9a3 from "./Phyquestions/Chapter-5/9 (3).png"
import Ch5q9a4 from "./Phyquestions/Chapter-5/9 (4).png"

import Ch5q10 from "./Phyquestions/Chapter-5/10.png"
import Ch5q10a1 from "./Phyquestions/Chapter-5/10 (1).png"
import Ch5q10a2 from "./Phyquestions/Chapter-5/10 (2).png"
import Ch5q10a3 from "./Phyquestions/Chapter-5/10 (3).png"
import Ch5q10a4 from "./Phyquestions/Chapter-5/10 (4).png"

import Ch5q11 from "./Phyquestions/Chapter-5/11.png"
import Ch5q11a1 from "./Phyquestions/Chapter-5/11 (1).png"
import Ch5q11a2 from "./Phyquestions/Chapter-5/11 (2).png"
import Ch5q11a3 from "./Phyquestions/Chapter-5/11 (3).png"
import Ch5q11a4 from "./Phyquestions/Chapter-5/11 (4).png"

import Ch5q12 from "./Phyquestions/Chapter-5/12.png"
import Ch5q12a1 from "./Phyquestions/Chapter-5/12 (1).png"
import Ch5q12a2 from "./Phyquestions/Chapter-5/12 (2).png"
import Ch5q12a3 from "./Phyquestions/Chapter-5/12 (3).png"
import Ch5q12a4 from "./Phyquestions/Chapter-5/12 (4).png"

import Ch5q13 from "./Phyquestions/Chapter-5/13.png"
import Ch5q13a1 from "./Phyquestions/Chapter-5/13 (1).png"
import Ch5q13a2 from "./Phyquestions/Chapter-5/13 (2).png"
import Ch5q13a3 from "./Phyquestions/Chapter-5/13 (3).png"
import Ch5q13a4 from "./Phyquestions/Chapter-5/13 (4).png"

import Ch5q14 from "./Phyquestions/Chapter-5/14.png"
import Ch5q14a1 from "./Phyquestions/Chapter-5/14 (1).png"
import Ch5q14a2 from "./Phyquestions/Chapter-5/14 (2).png"
import Ch5q14a3 from "./Phyquestions/Chapter-5/14 (3).png"
import Ch5q14a4 from "./Phyquestions/Chapter-5/14 (4).png"

import Ch5q15 from "./Phyquestions/Chapter-5/15.png"
import Ch5q15a1 from "./Phyquestions/Chapter-5/15 (1).png"
import Ch5q15a2 from "./Phyquestions/Chapter-5/15 (2).png"
import Ch5q15a3 from "./Phyquestions/Chapter-5/15 (3).png"
import Ch5q15a4 from "./Phyquestions/Chapter-5/15 (4).png"
























export const newData = {
    chapters: [
      {
        chapter: "chapter-1",
        questions: [
          {
            question: Ch1q1,
            options: [
              Ch1q1a1,
              Ch1q1a2,
              Ch1q1a3,
              Ch1q1a4
            ],
            image: Ch1q1image,
            answer: Ch1q1a2,
            
          },
          {
            question: Ch1q2,
            options: [
              Ch1q2a1,
              Ch1q2a2,
              Ch1q2a3,
              Ch1q2a4
            ],
            answer: Ch1q2a3,
            
          },
          {
            question: Ch1q3,
            options: [
              Ch1q3a1,
              Ch1q3a2,
              Ch1q3a3,
              Ch1q3a4
            ],
            image: Ch1q3image,
            answer: Ch1q3a4,
            
            option_mode: "imagey"
          },
          {
            question: Ch1q4,
            options: [
              Ch1q4a1,
              Ch1q4a2,
              Ch1q4a3,
              Ch1q4a4
            ],
            answer:  Ch1q4a2,
            
          },
          {
            question: Ch1q5,
            options: [
              Ch1q5a1,
              Ch1q5a2,
              Ch1q5a3,
              Ch1q5a4
            ],
            image: Ch1q5image,
            answer:  Ch1q5a1,
            
          },
  
          {
            question: Ch1q6,
            options: [
              Ch1q6a1,
              Ch1q6a2,
              Ch1q6a3,
              Ch1q6a4
            ],
            image:Ch1q6image,
            answer:  Ch1q6a2,
            
            option_mode: "imagey"
          },
  
          {
            question: Ch1q7,
            options: [
              Ch1q7a1,
              Ch1q7a2,
              Ch1q7a3,
              Ch1q7a4
            ],
            answer: Ch1q7a3,
            
          },
          {
            question: Ch1q8,
            options: [
              Ch1q8a1,
              Ch1q8a2,
              Ch1q8a3,
              Ch1q8a4
            ],
            image:Ch1q8a1,
            answer: "./Phyquestions/Chapter-1/8 (1).png",
            
          },
          {
            question: Ch1q9,
            options: [
              Ch1q9a1,
              Ch1q9a2,
              Ch1q9a3,
              Ch1q9a4
            ],
            answer: Ch1q9a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch1q10,
            options: [
              Ch1q10a1,
              Ch1q10a2,
              Ch1q10a3,
              Ch1q10a4
            ],
            answer: Ch1q10a2,
            
            option_mode: "image"
          },
          {
            question: Ch1q11,
            options: [
              Ch1q11a1,
              Ch1q11a2,
              Ch1q11a3,
              Ch1q11a4
            ],
            answer:  Ch1q11a1,
            
          },
          {
            question: Ch1q12,
            options: [
              Ch1q12a1,
              Ch1q12a2,
              Ch1q12a3,
              Ch1q12a4
            ],
            answer: Ch1q12a3,
            
          },
          {
            question: Ch1q13,
            options: [
              Ch1q13a1,
              Ch1q13a2,
              Ch1q13a3,
              Ch1q13a4
            ],
            answer: Ch1q13a4,
            
          },
          {
            question: Ch1q14,
            options: [
              Ch1q14a1,
              Ch1q14a2,
              Ch1q14a3,
              Ch1q14a4
            ],
            image: Ch1q14image,
            answer:Ch1q14a2,
            
            option_mode: "imagey"
          },
          {
            question: Ch1q15,
            options: [
              Ch1q15a1,
              Ch1q15a2,
              Ch1q15a3,
              Ch1q15a4
            ],
            answer: Ch1q15a1,
            
          }
        ]
      },
      {
        chapter: "chapter-2",
        questions: [
          {
            question: Ch2q1,
            options: [
              Ch2q1a1,
              Ch2q1a2,
              Ch2q1a3,
              Ch2q1a4
            ],
           
            answer: Ch2q1a1,
            option_mode: "imagey",
            image:Ch2q1image
            
          },
          {
            question: Ch2q2,
            options: [
              Ch2q2a1,
              Ch2q2a2,
              Ch2q2a3,
              Ch2q2a4
            ],
            answer: Ch2q2a1,
            option_mode: "imagey",
            image:Ch2q2image
            
          },
          {
            question: Ch2q3,
            options: [
              Ch2q3a1,
              Ch2q3a2,
              Ch2q3a3,
              Ch2q3a4
            ],
           
            answer: Ch2q3a3,
            
           
          },
          {
            question: Ch2q4,
            options: [
              Ch2q4a1,
              Ch2q4a2,
              Ch2q4a3,
              Ch2q4a4
            ],
            answer:  Ch2q4a2,
            
          },
          {
            question: Ch2q5,
            options: [
              Ch2q5a1,
              Ch2q5a2,
              Ch2q5a3,
              Ch2q5a4
            ],
            image: Ch2q5image,
            answer:  Ch2q5a1,
            
          },
    
          {
            question: Ch2q6,
            options: [
              Ch2q6a1,
              Ch2q6a2,
              Ch2q6a3,
              Ch2q6a4
            ],
     
            answer:  Ch2q6a3,
            
            option_mode: "imagey"
          },
    
          {
            question: Ch2q7,
            options: [
              Ch2q7a1,
              Ch2q7a2,
              Ch2q7a3,
              Ch2q7a4
            ],
            answer: Ch2q7a4,
            
          },
          {
            question: Ch2q8,
            options: [
              Ch2q8a1,
              Ch2q8a2,
              Ch2q8a3,
              Ch2q8a4
            ],
           
            answer: Ch2q8a3,
            option_mode: "imagey"
          },
          {
            question: Ch2q9,
            options: [
              Ch2q9a1,
              Ch2q9a2,
              Ch2q9a3,
              Ch2q9a4
            ],
            answer: Ch2q9a4,
            
            
          },
          {
            question: Ch2q10,
            options: [
              Ch2q10a1,
              Ch2q10a2,
              Ch2q10a3,
              Ch2q10a4
            ],
            answer: Ch2q10a3,
            
            option_mode: "image"
          },
          {
            question: Ch2q11,
            options: [
              Ch2q11a1,
              Ch2q11a2,
              Ch2q11a3,
              Ch2q11a4
            ],
            answer:  Ch2q11a1,
            image: Ch2q11image
            
          },
          {
            question: Ch2q12,
            options: [
              Ch2q12a1,
              Ch2q12a2,
              Ch2q12a3,
              Ch2q12a4
            ],
            answer: Ch2q12a4,
            
          },
          {
            question: Ch2q13,
            options: [
              Ch2q13a1,
              Ch2q13a2,
              Ch2q13a3,
              Ch2q13a4
            ],
            answer: Ch2q13a2,
            
          },
          {
            question: Ch2q14,
            options: [
              Ch2q14a1,
              Ch2q14a2,
              Ch2q14a3,
              Ch2q14a4
            ],
            
            answer:Ch2q14a4,
            
        
            
          },
          {
            question: Ch2q15,
            options: [
              Ch2q15a1,
              Ch2q15a2,
              Ch2q15a3,
              Ch2q15a4
            ],
            answer: Ch2q15a1,
            
          }
        ]
      },
  
      {
        chapter: "chapter-3",
        questions: [
          {
            question: Ch3q1,
            options: [
              Ch3q1a1,
              Ch3q1a2,
              Ch3q1a3,
              Ch3q1a4
            ],
           
            answer: Ch3q1a1,
            option_mode: "imagey",
            image: Ch3q1image,
            
          },
          {
            question: Ch3q2,
            options: [
              Ch3q2a1,
              Ch3q2a2,
              Ch3q2a3,
              Ch3q2a4
            ],
            answer: Ch3q2a4,
            option_mode: "imagey",
            image: Ch3q2image,
            
          },
          {
            question: Ch3q3,
            options: [
              Ch3q3a1,
              Ch3q3a2,
              Ch3q3a3,
              Ch3q3a4
            ],
            
            answer: Ch3q3a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch3q4,
            options: [
              Ch3q4a1,
              Ch3q4a2,
              Ch3q4a3,
              Ch3q4a4
            ],
            answer:  Ch3q4a2,
            
          },
          {
            question: Ch3q5,
            options: [
              Ch3q5a1,
              Ch3q5a2,
              Ch3q5a3,
              Ch3q5a4
            ],
           
            answer:  Ch3q5a2,
            
          },
    
          {
            question: Ch3q6,
            options: [
              Ch3q6a1,
              Ch3q6a2,
              Ch3q6a3,
              Ch3q6a4
            ],
            
            answer:  Ch3q6a1,
            
           
          },
    
          {
            question: Ch3q7,
            options: [
              Ch3q7a1,
              Ch3q7a2,
              Ch3q7a3,
              Ch3q7a4
            ],
            
            answer: Ch3q7a2,
            image: Ch3q7image,
            option_mode: "imagey"
            
          },
          {
            question: Ch3q8,
            options: [
              Ch3q8a1,
              Ch3q8a2,
              Ch3q8a3,
              Ch3q8a4
            ],
            
            answer: Ch3q8a1,
            option_mode:"imagey"
            
          },
          {
            question: Ch3q9,
            options: [
              Ch3q9a1,
              Ch3q9a2,
              Ch3q9a3,
              Ch3q9a4
            ],
            answer: Ch3q9a2,
            image: Ch3q9image,
            option_mode: "imagey"
          },
          {
            question: Ch3q10,
            options: [
              Ch3q10a1,
              Ch3q10a2,
              Ch3q10a3,
              Ch3q10a4
            ],
            answer: Ch3q10a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch3q11,
            options: [
              Ch3q11a1,
              Ch3q11a2,
              Ch3q11a3,
              Ch3q11a4
            ],
            answer:  Ch3q11a3,
            
          },
          {
            question: Ch3q12,
            options: [
              Ch3q12a1,
              Ch3q12a2,
              Ch3q12a3,
              Ch3q12a4
            ],
            answer: Ch3q12a3,
            
          },
          {
            question: Ch3q13,
            options: [
              Ch3q13a1,
              Ch3q13a2,
              Ch3q13a3,
              Ch3q13a4
            ],
            answer: Ch3q13a2,
            
          },
          {
            question: Ch3q14,
            options: [
              Ch3q14a1,
              Ch3q14a2,
              Ch3q14a3,
              Ch3q14a4
            ],
            
            answer:Ch3q14a4,
            
            option_mode: "imagey"
          },
          {
            question: Ch3q15,
            options: [
              Ch3q15a1,
              Ch3q15a2,
              Ch3q15a3,
              Ch3q15a4
            ],
            answer: Ch3q15a3,
            
          }
        ]
      },
  
      {
        chapter: "chapter-4",
        questions: [
          {
            question: Ch4q1,
            options: [
              Ch4q1a1,
              Ch4q1a2,
              Ch4q1a3,
              Ch4q1a4
            ],
           
            answer: Ch4q1a1,
            image: Ch4q1image,
             option_mode: "imagez"
            
          },
          {
            question: Ch4q2,
            options: [
              Ch4q2a1,
              Ch4q2a2,
              Ch4q2a3,
              Ch4q2a4
            ],
            image: Ch4q2image,
            answer: Ch4q2a4,
             option_mode: "imagez"
            
          },
          {
            question: Ch4q3,
            options: [
              Ch4q3a1,
              Ch4q3a2,
              Ch4q3a3,
              Ch4q3a4
            ],
            
            answer: Ch4q3a2,
            
         
          },
          {
            question: Ch4q4,
            options: [
              Ch4q4a1,
              Ch4q4a2,
              Ch4q4a3,
              Ch4q4a4
            ],
            answer:  Ch4q4a4,
            
          },
          {
            question: Ch4q5,
            options: [
              Ch4q5a1,
              Ch4q5a2,
              Ch4q5a3,
              Ch4q5a4
            ],
            image: Ch4q5image,
            answer:  Ch4q5a1,
             option_mode: "image"
            
          },
    
          {
            question: Ch4q6,
            options: [
              Ch4q6a1,
              Ch4q6a2,
              Ch4q6a3,
              Ch4q6a4
            ],
            
            answer:  Ch4q6a1,
            
           
          },
    
          {
            question: Ch4q7,
            options: [
              Ch4q7a1,
              Ch4q7a2,
              Ch4q7a3,
              Ch4q7a4
            ],
            answer: Ch4q7a1,
            
          },
          {
            question: Ch4q8,
            options: [
              Ch4q8a1,
              Ch4q8a2,
              Ch4q8a3,
              Ch4q8a4
            ],
            
            answer: Ch4q8a2,
            
          },
          {
            question: Ch4q9,
            options: [
              Ch4q9a1,
              Ch4q9a2,
              Ch4q9a3,
              Ch4q9a4
            ],
            answer: Ch4q9a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch4q10,
            options: [
              Ch4q10a1,
              Ch4q10a2,
              Ch4q10a3,
              Ch4q10a4
            ],
            answer: Ch4q10a1,
            
            option_mode: "imagey"
          },
          {
            question: Ch4q11,
            options: [
              Ch4q11a1,
              Ch4q11a2,
              Ch4q11a3,
              Ch4q11a4
            ],
            answer:  Ch4q11a3,
            
          },
          {
            question: Ch4q12,
            options: [
              Ch4q12a1,
              Ch4q12a2,
              Ch4q12a3,
              Ch4q12a4
            ],
            answer: Ch4q12a3,
            
          },
          {
            question: Ch4q13,
            options: [
              Ch4q13a1,
              Ch4q13a2,
              Ch4q13a3,
              Ch4q13a4
            ],
            answer: Ch4q13a4,
            option_mode: "imagey"
            
          },
          {
            question: Ch4q14,
            options: [
              Ch4q14a1,
              Ch4q14a2,
              Ch4q14a3,
              Ch4q14a4
            ],
            
            answer:Ch4q14a3,
            
            option_mode: "imagey"
          },
          {
            question: Ch4q15,
            options: [
              Ch4q15a1,
              Ch4q15a2,
              Ch4q15a3,
              Ch4q15a4
            ],
            answer: Ch4q15a4,
            
          }
        ]
      },
      {
        chapter: "chapter-5",
        questions: [
          {
            question: Ch5q1,
            options: [
              Ch5q1a1,
              Ch5q1a2,
              Ch5q1a3,
              Ch5q1a4
            ],
           
            answer: Ch5q1a2,
            
          },
          {
            question: Ch5q2,
            options: [
              Ch5q2a1,
              Ch5q2a2,
              Ch5q2a3,
              Ch5q2a4
            ],
            answer: Ch5q2a4,
            
          },
          {
            question: Ch5q3,
            options: [
              Ch5q3a1,
              Ch5q3a2,
              Ch5q3a3,
              Ch5q3a4
            ],
           
            answer: Ch5q3a4,
            
            
          },
          {
            question: Ch5q4,
            options: [
              Ch5q4a1,
              Ch5q4a2,
              Ch5q4a3,
              Ch5q4a4
            ],
            answer:  Ch5q4a3,
            
          },
          {
            question: Ch5q5,
            options: [
              Ch5q5a1,
              Ch5q5a2,
              Ch5q5a3,
              Ch5q5a4
            ],
           
            answer:  Ch5q5a1,
            
          },
    
          {
            question: Ch5q6,
            options: [
              Ch5q6a1,
              Ch5q6a2,
              Ch5q6a3,
              Ch5q6a4
            ],
            
            answer:  Ch5q6a2,
            
         
          },
    
          {
            question: Ch5q7,
            options: [
              Ch5q7a1,
              Ch5q7a2,
              Ch5q7a3,
              Ch5q7a4
            ],
            answer: Ch5q7a1,
            
          },
          {
            question: Ch5q8,
            options: [
              Ch5q8a1,
              Ch5q8a2,
              Ch5q8a3,
              Ch5q8a4
            ],
          
            answer: Ch5q8a3,
            
          },
          {
            question: Ch5q9,
            options: [
              Ch5q9a1,
              Ch5q9a2,
              Ch5q9a3,
              Ch5q9a4
            ],
            answer: Ch5q9a2,
            
           
          },
          {
            question: Ch5q10,
            options: [
              Ch5q10a1,
              Ch5q10a2,
              Ch5q10a3,
              Ch5q10a4
            ],
            answer: Ch5q10a2,
            
          
          },
          {
            question: Ch5q11,
            options: [
              Ch5q11a1,
              Ch5q11a2,
              Ch5q11a3,
              Ch5q11a4
            ],
            answer:  Ch5q11a3,
            
          },
          {
            question: Ch5q12,
            options: [
              Ch5q12a1,
              Ch5q12a2,
              Ch5q12a3,
              Ch5q12a4
            ],
            answer: Ch5q12a1,
            
          },
          {
            question: Ch5q13,
            options: [
              Ch5q13a1,
              Ch5q13a2,
              Ch5q13a3,
              Ch5q13a4
            ],
            answer: Ch5q13a4,
            
          },
          {
            question: Ch5q14,
            options: [
              Ch5q14a1,
              Ch5q14a2,
              Ch5q14a3,
              Ch5q14a4
            ],
            
            answer:Ch5q14a4,
            
            option_mode: "imagez"
          },
          {
            question: Ch5q15,
            options: [
              Ch5q15a1,
              Ch5q15a2,
              Ch5q15a3,
              Ch5q15a4
            ],
            answer: Ch5q15a1,
            
          }
        ]
      }
    
  
      
    ]
  }
  