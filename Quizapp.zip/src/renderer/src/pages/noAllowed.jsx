import React from "react";
import { Link } from "react-router-dom";

const NotAllowed = () => {
  return (
    <section
      style={{
        width: "100dvw",
        height: "100dvh",
        display: "flex",
        alignItems: "center",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <h2 style={{ fontSize: "5rem" }}>Oops!</h2>
      <span style={{ fontSize: "2rem", marginTop: "40px" }}>
        You are not allowed to access the quiz
      </span>
      <Link to={"/"} style={{ textDecoration: "none" }}>
        <button
          style={{
            padding: "20px 30px",
            fontSize: "1.5rem",
            background: "#03a9f4",
            borderRadius: "10px",
            color: "#f1f1f1",
            marginTop: "30px",
          }}
        >
          Back to Home
        </button>
      </Link>
    </section>
  );
};

export default NotAllowed;
