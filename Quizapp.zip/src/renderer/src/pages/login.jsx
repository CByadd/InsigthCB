import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
// import credentials from "../json/credentials"; // Adjust the path based on where you save the file

// src/json/credentials.jssrc/renderer/src/json/Userimages/1.jpg

import img1 from './../Userimages/1.png'
import img7 from './../Userimages/7.png'
import img9 from './../Userimages/9.png'
import img10 from './../Userimages/10.png'
import img11 from './../Userimages/11.png'
import img12 from './../Userimages/12.png'
import img13 from './../Userimages/13.png'
import img16 from './../Userimages/16.png'
import img21 from './../Userimages/21.png'
import img24 from './../Userimages/24.png'
import img26 from './../Userimages/26.png'
import img27 from './../Userimages/27.png'
import img28 from './../Userimages/28.png'
import img30 from './../Userimages/30.png'
import img34 from './../Userimages/34.png'
import img38 from './../Userimages/38.png'
import img39 from './../Userimages/39.png'
import img52 from './../Userimages/52.png'
import img55 from './../Userimages/55.png'
import img56 from './../Userimages/56.png'
import img61 from './../Userimages/61.png'
import img62 from './../Userimages/62.png'
import img63 from './../Userimages/63.png'
import img140 from './../Userimages/140.png'
import img186 from './../Userimages/186.png'
import img187 from './../Userimages/187.png'
import img201 from './../Userimages/201.png'
import img202 from './../Userimages/202.png'
import img203 from './../Userimages/203.png'
import img205 from './../Userimages/205.png'
import img208 from './../Userimages/208.png'
import img223 from './../Userimages/223.png'
import img224 from './../Userimages/224.png'
import img228 from './../Userimages/228.png'
import img231 from './../Userimages/231.png'
import img283 from './../Userimages/283.png'
import img287 from './../Userimages/287.png'
import img319 from './../Userimages/319.png'
import img325 from './../Userimages/325.png'
import img331 from './../Userimages/331.png'
import img332 from './../Userimages/332.png'


import img353 from './../Userimages/353.png'
import img354 from './../Userimages/354.png'
import img363 from './../Userimages/363.png'
import img372 from './../Userimages/372.png'
import img385 from './../Userimages/385.png'
import img386 from './../Userimages/386.png'
import img388 from './../Userimages/388.png'
import img403 from './../Userimages/403.png'
import img408 from './../Userimages/408.png'
import img412 from './../Userimages/412.png'
import img430 from './../Userimages/430.png'
import img432 from './../Userimages/432.png'
import img433 from './../Userimages/433.png'
import img460 from './../Userimages/460.png'
import img468 from './../Userimages/468.png'
import img487 from './../Userimages/487.png'
import img490 from './../Userimages/490.png'
import img500 from './../Userimages/500.png'
import img504 from './../Userimages/504.png'
import img507 from './../Userimages/507.png'
import img508 from './../Userimages/508.png'
import img509 from './../Userimages/509.png'
import img521 from './../Userimages/521.png'
import img522 from './../Userimages/522.png'
import img526 from './../Userimages/526.png'
import img527 from './../Userimages/527.png'
import img532 from './../Userimages/532.png'
import img542 from './../Userimages/542.png'
import img555 from './../Userimages/555.png'
import img556 from './../Userimages/556.png'
import img558 from './../Userimages/558.png'
import img560 from './../Userimages/560.png'
import img561 from './../Userimages/561.png'
import img563 from './../Userimages/563.png'
import srini from './../Userimages/Square.png'

const credentials = [
    {
        id: "Srinivash",
        name: "Srinivash",
        pass: "//",
        std: "12-B",
        idno: "12245",
        img: img1
    },
    {
        id: "//",
        name: "Srinivash-Developer",
        pass: "//",
        std: "Developer",
        idno: "#1",
        img: srini
    },
    {
        id: "Principal",
        name: "Bro.Sesuraj csc",
        pass: "//",
        std: "Principal",
        idno: "#1"
    },
    {
        id: "Vice Principal",
        name: "Mr.Guna",
        pass: "//",
        std: "Vice Principal",
        idno: "#1"
    },
    {
        id: "Jestin",
        name: "Jestin",
        pass: "//",
        std: "Developer",
        idno: "#1"
    },
    {
        id: "1",
        name: "Bro.SESURAJ CSC",
        pass: "1",
        std: "MANAGEMENT",
        img: img1,
        idno: "1"
    },
    {
        id: "7",
        name: "THIAGARAJAN N",
        pass: "7",
        std: "TEACHING",
        img: img7,
        idno: "7"
    },
    {
        id: "9",
        name: "MICHAEL GNANARAJ E",
        pass: "9",
        std: "TEACHING",
        img: img9,
        idno: "9"
    },
    {
        id: "10",
        name: "ANTHUVAN GUNASEELAN G",
        pass: "10",
        std: "TEACHING",
        img: img10,
        idno: "10"
    },
    {
        id: "11",
        name: "ARULMOZHI R",
        pass: "11",
        std: "TEACHING",
        img: img11,
        idno: "11"
    },
    {
        id: "12",
        name: "PATRIC RAJ R",
        pass: "12",
        std: "TEACHING",
        img: img12,
        idno: "12"
    },
    {
        id: "13",
        name: "RATHINARAJ A",
        pass: "13",
        std: "TEACHING",
        img: img13,
        idno: "13"
    },
    {
        id: "16",
        name: "MURALIDHARAN A R",
        pass: "16",
        std: "TEACHING",
        img: img16,
        idno: "16"
    },
    {
        id: "21",
        name: "MARIADASS M S",
        pass: "21",
        std: "TEACHING",
        img: img21,
        idno: "21"
    },
    {
        id: "24",
        name: "BALAKRISHNAN S",
        pass: "24",
        std: "TEACHING",
        img: img24,
        idno: "24"
    },
    {
        id: "26",
        name: "VIMALA TIPHAGNE T",
        pass: "26",
        std: "TEACHING",
        img: img26,
        idno: "26"
    },
    {
        id: "27",
        name: "ARUL J",
        pass: "27",
        std: "TEACHING",
        img: img27,
        idno: "27"
    },
    {
        id: "28",
        name: "DEVARAJAN S",
        pass: "28",
        std: "TEACHING",
        img: img28,
        idno: "28"
    },
    {
        id: "30",
        name: "JABARAJ A",
        pass: "30",
        std: "TEACHING",
        img: img30,
        idno: "30"
    },
    {
        id: "34",
        name: "ARUL JOSEPH A",
        pass: "34",
        std: "TEACHING",
        img: img34,
        idno: "34"
    },
    {
        id: "38",
        name: "AROCKIASAMY T",
        pass: "38",
        std: "TEACHING",
        img: img38,
        idno: "38"
    },
    {
        id: "39",
        name: "SAGAYARAJ I",
        pass: "39",
        std: "TEACHING",
        img: img39,
        idno: "39"
    },
    {
        id: "52",
        name: "LEO ANAND RAJ J",
        pass: "52",
        std: "TEACHING",
        img: img52,
        idno: "52"
    },
    {
        id: "55",
        name: "NATARAJAN S",
        pass: "55",
        std: "TEACHING",
        img: img55,
        idno: "55"
    },
    {
        id: "56",
        name: "NAZIA Y",
        pass: "56",
        std: "TEACHING",
        img: img56,
        idno: "56"
    },
    {
        id: "61",
        name: "ARUN BOSCO C",
        pass: "61",
        std: "TEACHING",
        img: img61,
        idno: "61"
    },
    {
        id: "62",
        name: "VEDAVALLI M R",
        pass: "62",
        std: "TEACHING",
        img: img62,
        idno: "62"
    },
    {
        id: "63",
        name: "ARUN FRANKLIN S",
        pass: "63",
        std: "TEACHING",
        img: img63,
        idno: "63"
    },
    {
        id: "140",
        name: "VIJAYA LAVANYA P",
        pass: "140",
        std: "TEACHING",
        img: img140,
        idno: "140"
    },
    {
        id: "186",
        name: "JESTIN JAYA KUMAR M",
        pass: "186",
        std: "TEACHING",
        img: img186,
        idno: "186"
    },
    {
        id: "187",
        name: "VIJAY JOSEPH S",
        pass: "187",
        std: "TEACHING",
        img: img187,
        idno: "187"
    },
    {
        id: "201",
        name: "JOHNY P",
        pass: "201",
        std: "TEACHING",
        img: img201,
        idno: "201"
    },
    {
        id: "202",
        name: "CHARLES A",
        pass: "202",
        std: "TEACHING",
        img: img202,
        idno: "202"
    },
    {
        id: "203",
        name: "JOHNSON ROBERT S",
        pass: "203",
        std: "TEACHING",
        img: img203,
        idno: "203"
    },
    {
        id: "205",
        name: "MOHANA G",
        pass: "205",
        std: "TEACHING",
        img: img205,
        idno: "205"
    },
    {
        id: "208",
        name: "SELVI P",
        pass: "208",
        std: "TEACHING",
        img: img208,
        idno: "208"
    },
    {
        id: "223",
        name: "SURYA  L",
        pass: "223",
        std: "TEACHING",
        img: img223,
        idno: "223"
    },
    {
        id: "224",
        name: "VARADARAJU V",
        pass: "224",
        std: "TEACHING",
        img: img224,
        idno: "224"
    },
    {
        id: "228",
        name: "SUNDARARAJAN",
        pass: "228",
        std: "SPECIAL TEACHERS",
        img: img228,
        idno: "228"
    },
    {
        id: "231",
        name: "ARUL SELVI A",
        pass: "231",
        std: "TEACHING",
        img: img231,
        idno: "231"
    },
    {
        id: "283",
        name: "JOSEPH JESSIE JAMES L",
        pass: "283",
        std: "TEACHING",
        img: img283,
        idno: "283"
    },
    {
        id: "287",
        name: "LEO X",
        pass: "287",
        std: "TEACHING",
        img: img287,
        idno: "287"
    },
    {
        id: "319",
        name: "SURULI NATHAN R",
        pass: "319",
        std: "TEACHING",
        img: img319,
        idno: "319"
    },
    {
        id: "325",
        name: "SELVAKUMAR C",
        pass: "325",
        std: "TEACHING",
        img: img325,
        idno: "325"
    },
    {
        id: "331",
        name: "IRUDAYARAJ S",
        pass: "331",
        std: "TEACHING",
        img: img331,
        idno: "331"
    },
    {
        id: "332",
        name: "ARTHI PRIYA V",
        pass: "332",
        std: "TEACHING",
        img: img332,
        idno: "332"
    },


    {
        id: "353",
        name: "GAYATHRI M",
        pass: "353",
        std: "TEACHING",
        img: img353,
        idno: "353"
    },
    {
        id: "354",
        name: "RUBY MARY J",
        pass: "354",
        std: "TEACHING",
        img: img354,
        idno: "354"
    },
    {
        id: "363",
        name: "GEORGE JOSE",
        pass: "363",
        std: "TEACHING",
        img: img363,
        idno: "363"
    },
    {
        id: "372",
        name: "SUMATHI N",
        pass: "372",
        std: "TEACHING",
        img: img372,
        idno: "372"
    },
    {
        id: "385",
        name: "SABARINATHAN M",
        pass: "385",
        std: "TEACHING",
        img: img385,
        idno: "385"
    },
    {
        id: "386",
        name: "JERALD A",
        pass: "386",
        std: "TEACHING",
        img: img386,
        idno: "386"
    },
    {
        id: "388",
        name: "PRIYA P",
        pass: "388",
        std: "TEACHING",
        img: img388,
        idno: "388"
    },
    {
        id: "403",
        name: "SALOMI RANI J",
        pass: "403",
        std: "TEACHING",
        img: img403,
        idno: "403"
    },
    {
        id: "408",
        name: "PRAKASH D",
        pass: "408",
        std: "TEACHING",
        img: img408,
        idno: "408"
    },
    {
        id: "412",
        name: "JUSTIN DIRAVIAM A",
        pass: "412",
        std: "TEACHING",
        img: img412,
        idno: "412"
    },
    {
        id: "430",
        name: "ABRAHAM I",
        pass: "430",
        std: "TEACHING",
        img: img430,
        idno: "430"
    },
    {
        id: "432",
        name: "FELIX RANI MARY",
        pass: "432",
        std: "TEACHING",
        img: img432,
        idno: "432"
    },
    {
        id: "433",
        name: "LEO J",
        pass: "433",
        std: "TEACHING",
        img: img433,
        idno: "433"
    },
    {
        id: "460",
        name: "SHARMILA X",
        pass: "460",
        std: "TEACHING",
        img: img460,
        idno: "460"
    },
    {
        id: "468",
        name: "FRANCIS B",
        pass: "468",
        std: "TEACHING",
        img: img468,
        idno: "468"
    },
    {
        id: "487",
        name: "VASANTHA PRIYA S",
        pass: "487",
        std: "TEACHING",
        img: img487,
        idno: "487"
    },
    {
        id: "490",
        name: "VASANTH L",
        pass: "490",
        std: "TEACHING",
        img: img490,
        idno: "490"
    },
    {
        id: "500",
        name: "SHARMILA V",
        pass: "500",
        std: "TEACHING",
        img: img500,
        idno: "500"
    },
    {
        id: "504",
        name: "AHILA R",
        pass: "504",
        std: "TEACHING",
        img: img504,
        idno: "504"
    },
    {
        id: "507",
        name: "REMO PAUL A",
        pass: "507",
        std: "TEACHING",
        img: img507,
        idno: "507"
    },
    {
        id: "508",
        name: "PIOUS PRIYAN T",
        pass: "508",
        std: "TEACHING",
        img: img508,
        idno: "508"
    },
    {
        id: "509",
        name: "AROKIYA RAJ D",
        pass: "509",
        std: "TEACHING",
        img: img509,
        idno: "509"
    },
    {
        id: "521",
        name: "SUGUNA DEVI S",
        pass: "521",
        std: "TEACHING",
        img: img521,
        idno: "521"
    },
    {
        id: "522",
        name: "JASMINE GLAFFIRA M",
        pass: "522",
        std: "TEACHING",
        img: img522,
        idno: "522"
    },
    {
        id: "526",
        name: "NIRMAL KUMAR K",
        pass: "526",
        std: "TEACHING",
        img: img526,
        idno: "526"
    },
    {
        id: "527",
        name: "ANTO PRIYANTHI A",
        pass: "527",
        std: "TEACHING",
        img: img527,
        idno: "527"
    },
    {
        id: "532",
        name: "GAYATHIRI S",
        pass: "532",
        std: "TEACHING",
        img: img532,
        idno: "532"
    },
    {
        id: "542",
        name: "Bro.THASAN D CSC",
        pass: "542",
        std: "MANAGEMENT",
        img: img542,
        idno: "542"
    },
    {
        id: "555",
        name: "SURYA(FRENCH)",
        pass: "555",
        std: "SPECIAL TEACHERS",
        img: img555,
        idno: "555"
    },
    {
        id: "556",
        name: "SUNDARAVARADHAN S",
        pass: "556",
        std: "SPECIAL TEACHERS",
        img: img556,
        idno: "556"
    },
    {
        id: "558",
        name: "SANTHIYA K",
        pass: "558",
        std: "TEACHING",
        img: img558,
        idno: "558"
    },
    {
        id: "560",
        name: "VENGATESHAN P",
        pass: "560",
        std: "TEACHING",
        img: img560,
        idno: "560"
    },
    {
        id: "561",
        name: "ELANGO T",
        pass: "561",
        std: "TEACHING",
        img: img561,
        idno: "561"
    },

];




const SERVER_IP = "192.168.1.43"; // Replace with your actual server IP

const Login = () => {
    const [id, setId] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [isLoginEnabled, setIsLoginEnabled] = useState(false); // Initially false
    const [selectedOption, setSelectedOption] = useState(null); // To store selected volume or random
    const [showAccessDenied, setShowAccessDenied] = useState(false); // To control access denied notification
    const navigate = useNavigate();

    useEffect(() => {
        // Create a WebSocket connection
        const socket = new WebSocket(`ws://${SERVER_IP}:8080`);

        socket.onopen = () => {
            console.log("WebSocket Client Connected");
            // Send initial message to identify the app
            socket.send(JSON.stringify({ type: 'app', appName: 'login' }));
        };

        socket.onmessage = (event) => {
            // Handle incoming messages from the server
            const data = JSON.parse(event.data);
            console.log("Received message from server:", data);

            if (data.type === "loginStatus") {
                console.log("Login status received:", data.isEnabled);
                setIsLoginEnabled(data.isEnabled);
            } else if (data.type === "selection") {
                console.log("Quiz selection option received:", data.option);
                setSelectedOption(data.option); // Could be 1, 2, or 'random'
            }
        };

        socket.onclose = () => {
            console.log("WebSocket Client Disconnected");
        };

        socket.onerror = (error) => {
            console.error("WebSocket error:", error);
        };

        // Cleanup on component unmount
        return () => {
            if (socket.readyState === WebSocket.OPEN) {
                socket.close();
            }
        };
    }, []);



    const handleSubmit = (e) => {
        e.preventDefault();

        console.log("Attempting to log in with ID:", id);
        console.log("Selected Option:", selectedOption); // Debug log for selectedOption

        // Check if login is enabled
       
        // Validate user credentials
        const user = credentials.find(
            (cred) => cred.id === id && cred.pass === password
        );

        if (user) {
            console.log("User authenticated successfully:", user);
            localStorage.setItem("user", JSON.stringify(user)); // Save user data in local storage

            // Navigate to the appropriate quiz based on selectedOption
            if (selectedOption === 'தமிழ்') {
                console.log("Navigating to Quiz Volume 1");
                navigate("/quizvolume1", { state: { user } });
            } else if (selectedOption === 'Maths') {
                console.log("Navigating to Quiz Volume 2");
                navigate("/quizvolume2", { state: { user } });
            } 


          
            else if (selectedOption === 'Physics-Public Pattern') {
                console.log("Navigating to Random Quiz");
                navigate("/phy-random", { state: { user } });
            }
            else if (selectedOption === 'Physics-volume-1') {
                console.log("Navigating to Random Quiz");
                navigate("/phy-volume-1", { state: { user } });
            }
            else if (selectedOption === 'Physics-volume-2') {
                console.log("Navigating to Random Quiz");
                navigate("/phy-volume-2", { state: { user } });
            }
            else if (selectedOption === 'Physics-Chapterwise') {
                console.log("Navigating to Random Quiz");
                navigate("/phychapterwise", { state: { user } });
            }


            else if (selectedOption === 'Tamil Public Pattern') {
                console.log("Navigating to Random Quiz");
                navigate("/tamilrandom", { state: { user } });
            }
            else if (selectedOption === 'Tamil Chapterwise') {
                console.log("Navigating to Random Quiz");
                navigate("/tamilchapterwise", { state: { user } });
            }
            else if (selectedOption === 'Tamil Full Portion') {
                console.log("Navigating to Random Quiz");
                navigate("/tamilfullportion", { state: { user } });
            }


            else if (selectedOption === 'Commerce Public Pattern') {
                console.log("Navigating to Random Quiz");
                navigate("/commercerandom", { state: { user } });
            }
            else if (selectedOption === 'Commerce Chapterwise') {
                console.log("Navigating to Random Quiz");
                navigate("/commercechapterwise", { state: { user } });
            }
            else if (selectedOption === 'Commerce Full Portion') {
                console.log("Navigating to Random Quiz");
                navigate("/commercefullportion", { state: { user } });
            }




            else if (selectedOption === '12') {
                console.log("Navigating to Random Quiz");
                navigate("/phy-random", { state: { user } });
            }
             else {
                console.log("No quiz selection available. Current selectedOption:", selectedOption);
                setError("Quiz selection is not available.");
            }
        } else {
            console.log("Invalid ID or Password entered.");
            setError("Invalid ID or Password");
        }
    };


    return (
        <div>
            <section className="login_main_container">
                <div className="login_box">
                    <h1>Insight CB</h1>
                    <form onSubmit={handleSubmit}>
                        <input
                            type="text"
                            placeholder="Type your ID"
                            value={id}
                            onChange={(e) => setId(e.target.value)}
                        />
                        <input
                            type="password"
                            placeholder="Type your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <span className="buttoncon">
                            <button type="submit" >Login</button>
                        </span>
                        {error && <p className="error">{error}</p>}
                    </form>
                </div>
                {showAccessDenied && (
                    <div className="toast-notification">
                        <p>Access Denied: Login is currently disabled.</p>
                    </div>
                )}
            </section>

            <span className="mobile-view">
                <h1>Please view it on Desktop</h1>
            </span>
        </div>
    );
};

export default Login;
