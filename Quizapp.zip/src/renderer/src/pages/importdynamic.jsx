import React from 'react'
import q10 from './../Maths/q10.png';

const Importdynamic = () => {
  return (
    <div>
        <img src={q10} alt="q10" />
    </div>
  )
}

export default Importdynamic